import client from "./client";

const create = (reportDetails) => client.post("/reports/new", reportDetails);

const get = (locs, searchKeyword) =>
  client.get(`/reports?locs=${locs}&seacrhKeyword=${searchKeyword}`);

const getMe = () => client.get("/reports/me");

export default {
  create,
  get,
  getMe,
};
