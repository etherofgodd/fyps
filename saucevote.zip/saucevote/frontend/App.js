import * as React from 'react';
import {NavigationContainer} from '@react-navigation/native';

// state management
import store from './app/redux/store';
import {Provider} from 'react-redux';
import RootStackNavigator from './app/routes/RootStackNavigator';

export default function App() {
  return (
    <Provider store={store}>
      <NavigationContainer>
        <RootStackNavigator />
      </NavigationContainer>
    </Provider>
  );
}
