import "./Home.css";

function Home() {
  return (
    <article className="post">
      <h2>Drug Addiction: Human Plague of the century</h2>

      <p>Dear Addict,</p>

      <p>
        Even at times when the need to feel the needle feels imminent the act of
        abstinence is essential, not just to you, but to those who loves you.
      </p>

      <p>
        She said that he loved baseball, and James Earl Jones; said that he's
        got god talking inside of his thoughts while he's rounding those bases
        on his way back home, but the drugs had it's way
      </p>

      <blockquote>
        <p>You’ve got a pain deep in your bones, son.</p>
      </blockquote>
      <p>
        "You’ve got a pain deep in your bones, son. It compels you forward like
        you’re tied to a slave master’s cruel hand, and it's the same pain that
        drives that oppressor’s heart of stone, so you’ve grown to love the man.
        You keep pouring yourself out, again and again, into legible lines
        through a crooked pen." Yeah, it’s painful, but it’s familiar – so habit
        breeds comfort, and I don’t know what I’d do without him
      </p>

      <h2>Dear Time</h2>

      <p>
        Grandfather's as creaky as his front porch, scent like oil in the gun
        barrel, dip-can kicked over the railing, sandpaper hands stuck behind
        thumb tacks on my wall. I’ve got an ache in my chest for every season I
        miss and it gets worse when the snow starts to fall. There are
        butterflies alive in that couple’s eyes a few years since forgotten by
        all, and sometimes, if the phone starts to ring, I can still hear their
        wings when you call
      </p>

      <p>
        But I begged for movement and I got what I asked for, and I can picture
        the answer like it came yesterday. And in the land of the gods, I think
        that things are timeless, but we are still prone to decay
      </p>

      <p>
        You know I still lift up hope of certain smiles in those photos for us
        when I pray
      </p>

      <blockquote>
        <p>"Idle hands build nothing that you can call your own"</p>
      </blockquote>

      <p>
        Drug abuse it self has lead to the destruction of the future of the best
        and brightest people in the world, ColdTurkey helps us analyze the
        effects of our addiction and then recommends the closest rehab centers
        available to us. Doing Nothing can affect addicts to a great extent, get
        some help!
      </p>

      <blockquote>
        <p>— Chidera</p>
      </blockquote>
    </article>
  );
}

export default Home;
