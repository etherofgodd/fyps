import React from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const AppTextInput = ({
  iconLeft,
  iconRight,
  width = '100%',
  iconRightPress,
  ...otherProps
}) => {
  return (
    <View style={[styles.ctn, {width}]}>
      {iconLeft && (
        <MaterialCommunityIcons name={iconLeft} size={22} color="#0C2D48" />
      )}
      <TextInput
        placeholderTextColor="gray"
        style={styles.inputBtn}
        {...otherProps}
      />
      {iconRight && (
        <TouchableOpacity onPress={iconRightPress}>
          <MaterialCommunityIcons name={iconRight} size={22} color="#0C2D48" />
        </TouchableOpacity>
      )}
    </View>
  );
};

export default AppTextInput;

const styles = StyleSheet.create({
  ctn: {
    backgroundColor: '#eee',
    borderRadius: 10,
    flexDirection: 'row',
    padding: 10,
    marginVertical: 10,
    borderWidth: 2,
    borderColor: '#0C2D48',
    alignItems: 'center',
  },
  inputBtn: {
    fontWeight: '700',
    width: '85%',
    fontSize: 18,
  },
});
