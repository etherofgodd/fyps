import client from './client';

export const polls = () => client.get('/elections', {});
