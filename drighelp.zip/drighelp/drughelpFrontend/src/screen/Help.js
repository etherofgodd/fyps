import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Help.css";
import LoadingCtn from "../components/LoadingCtn";
// import map from "./map.png";

function Help() {
  const [drugValue, setDrugValue] = useState("none");
  const [drugs, setDrugs] = useState();
  const [drug, setDrug] = useState();
  const [addiction, setAddiction] = useState([]);
  const [loading, setLoading] = useState(false);
  const [newLoading, setNewLoading] = useState(false);
  const [diagnosedStage, setDiagnosedStage] = useState();

  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      window.location.replace("/signin");
    }
    getDrugs();
  }, []);

  useEffect(() => {
    getSingleDrug();
  }, [drugValue]);

  const getSingleDrug = async () => {
    if (drugValue !== "none") {
      try {
        const response = await axios.get(
          "http://localhost:10000/api/drug/single/" + drugValue
        );
        setDrug(response.data.drug);
      } catch (error) {
        console.log(error);
      }
    }
  };

  const getDrugs = async () => {
    try {
      const response = await axios.get("http://localhost:10000/api/drug");
      setDrugs(response.data.drugs);
    } catch (error) {
      console.log(error);
    }
  };

  const diagnose = (e) => {
    e.preventDefault();

    const dataset = Object.values(addiction);
    let stages = [];

    dataset.map((data) => stages.push(data.stage));

    setLoading(true);
    setTimeout(() => {
      if (stages.includes("3")) {
        setDiagnosedStage("Intense Abuser");
      } else if (stages.includes("2") && stages.includes("3") === false) {
        setDiagnosedStage("Mild abuser");
      } else if (
        stages.includes("1") &&
        stages.includes("3") === false &&
        stages.includes("2") === false
      ) {
        setDiagnosedStage("Beginning Stage");
      }
      setLoading(false);
    }, [5000]);
  };

  const toggleFunction = (sign) => {
    setAddiction((val) => ({
      ...val,
      [sign._id]: val[sign._id]
        ? null
        : {
            stage: sign.stage,
            sign: sign.sign,
          },
    }));
  };

  const handleSave = async (drug, diagnosis) => {
    setNewLoading(true);
    try {
      await axios.post(
        "http://localhost:10000/api/addiction",
        {
          drug,
          stage: diagnosis,
        },
        {
          headers: {
            authorization: "Bearer " + token,
          },
        }
      );
      alert("Diagnosis saved");
      setNewLoading(false);
    } catch (error) {
      setNewLoading(false);
      console.log(error);
    }
  };

  return (
    <div>
      <h2 style={{ textAlign: "center" }}>Drugs Section</h2>
      <div className="choice_opt">
        <select
          name="drugs"
          id="drugs"
          defaultValue="none"
          onChange={(e) => setDrugValue(e.target.value)}
        >
          <option value="none">None</option>
          {drugs &&
            drugs.map((drug) => (
              <option value={drug._id} key={drug._id}>
                {" "}
                {drug.title}
              </option>
            ))}
        </select>
      </div>
      {drugValue === "none" ? (
        <div>
          <h2 style={{ textAlign: "center" }}>Please select a drug</h2>
        </div>
      ) : (
        drug && (
          <article className="post">
            <h2>Understanding {drug.title}</h2>
            <p>Dear Addict,</p>
            <p>{drug.info}</p>
            <blockquote>
              <p>{drug.title} Effects and Abuse</p>
            </blockquote>
            <p>{drug.effects.info} The effects include : </p>
            <ul style={{ color: "white", fontSize: "30px" }}>
              {drug.effects.effects.map((effect) => (
                <li key={effect}>{effect}</li>
              ))}
            </ul>

            <blockquote>
              <p>Signs of {drug.title} Addiction</p>
            </blockquote>

            <p>{drug.addiction.info}</p>

            <p>Kindly select the recognized addiction signs:</p>

            <form onSubmit={diagnose}>
              {drug.addiction.signs.map((sign) => (
                <div style={{ color: "white" }} className="form" key={sign._id}>
                  <input
                    className="form_input"
                    type="checkbox"
                    checked={addiction[sign._id]}
                    style={{ margin: "10px" }}
                    onChange={() => toggleFunction(sign)}
                  />
                  {"  "}
                  {sign.sign}
                </div>
              ))}
              {loading ? (
                <div style={{ alignSelf: "center", display: "flex" }}>
                  <LoadingCtn />

                  <div>
                    <h3 style={{ color: "white", marginTop: "30px" }}>
                      Please wait... running diagnosis on your data
                    </h3>
                  </div>
                </div>
              ) : (
                <button className="form_diagnose_btn">Diagnose</button>
              )}
            </form>

            {diagnosedStage && (
              <div>
                <p className="message">You are currently at stage :::</p>
                <p className="message_imp">{diagnosedStage}</p>
                <button
                  onClick={() => handleSave(drug.title, diagnosedStage)}
                  className="add_btn"
                  disabled={loading}
                >
                  Add to profile
                </button>
              </div>
            )}
          </article>
        )
      )}
    </div>
  );
}

export default Help;
