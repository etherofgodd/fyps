import {create} from 'apisauce';
import authStorage from '../auth/storage';

const URL ='https://saucevote.herokuapp.com/api';
 //"http://192.168.43.102:15000/api"
//'https://saucevote.herokuapp.com/api';

const client = create({
  baseURL: URL,
});
client.addAsyncRequestTransform(async req => {
  const bearerToken = await authStorage.getToken();
  if (!bearerToken) return;
  req.headers['Authorization'] = `Bearer ${bearerToken}`;
});

export default client;
