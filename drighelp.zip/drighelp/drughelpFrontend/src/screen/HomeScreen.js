import React from "react";
import Home from "../components/Home";

function HomeScreen() {
  return <Home />;
}

export default HomeScreen;
