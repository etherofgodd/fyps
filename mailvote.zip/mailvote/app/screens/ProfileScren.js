import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  Text,
  View,
  ScrollView,
} from 'react-native';
import {getUserProfile} from '../auth/authentication';
import {auth} from '../config/firebaseconnect';

const ProfileScren = () => {
  const [user, setUser] = useState([]);
  useEffect(() => {
    getUserProfileDetails();
  }, []);

  const getUserProfileDetails = async () => {
    const res = await getUserProfile();
    setUser(res);
  };

  return (
    <View style={styles.ctn}>
      <View style={styles.header}>
        <Text
          style={{
            fontSize: 30,
            fontWeight: 'bold',
          }}>
          CREDENTIALS
        </Text>
      </View>
      <ScrollView style={{width: '100%'}} showsVerticalScrollIndicator={false}>
        {user ? (
          <View>
            <View>
              <View style={{marginTop: 10}}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>EMAIL</Text>
              </View>
              <View style={styles.list}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  {user.email}
                </Text>
              </View>
            </View>
            <View>
              <View style={{marginTop: 10}}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  ACCOUNT NAME
                </Text>
              </View>
              <View style={styles.list}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  {user.account_name}
                </Text>
              </View>
            </View>
            <View>
              <View style={{marginTop: 10}}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  ACCOUNT NUMBER
                </Text>
              </View>
              <View style={styles.list}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  {user.account_number}
                </Text>
              </View>
            </View>
            <View>
              <View style={{marginTop: 10}}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>BVN</Text>
              </View>
              <View style={styles.list}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  {user.bvn}
                </Text>
              </View>
            </View>
            <View>
              <View style={{marginTop: 10}}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  STATE OF ORIGIN
                </Text>
              </View>
              <View style={styles.list}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  {user.state_of_origin}
                </Text>
              </View>
            </View>
            <View>
              <View style={{marginTop: 10}}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>VOTER ID</Text>
              </View>
              <View style={styles.list}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  {user.voterId}
                </Text>
              </View>
            </View>
            <View>
              <View style={{marginTop: 10}}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  PHONE NUMBER
                </Text>
              </View>
              <View style={styles.list}>
                <Text style={{fontWeight: 'bold', fontSize: 20}}>
                  {user.phonenumber}
                </Text>
              </View>
            </View>
          </View>
        ) : null}
        <View>
          <TouchableOpacity style={styles.btn} onPress={() => auth.signOut()}>
            <Text
              style={{
                fontWeight: 'bold',
                fontSize: 20,
                color: 'white',
              }}>
              Sign Out{' '}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

export default ProfileScren;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: 'white',
    padding: 10,
  },
  btn: {
    width: '60%',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#0C2D48',
    elevation: 2,
    borderRadius: 4,
    marginVertical: 20,
    alignSelf: 'center',
  },
  info: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  header: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    borderWidth: 2,
  },
  list: {
    padding: 20,
    borderWidth: 1,
    marginVertical: 10,
    backgroundColor: '#eee',
  },
});
