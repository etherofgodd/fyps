import React from "react";
import { StyleSheet, Text, TextInput, View } from "react-native";

const AppTextInput = ({
  inputLabel,
  multiline,
  placeholder,
  numberOfLines,
  ...otherProps
}) => {
  return (
    <View style={styles.from}>
      {inputLabel && <Text style={styles.fromTxt}>{inputLabel} : </Text>}
      <TextInput
        style={styles.locInput}
        multiline={multiline}
        numberOfLines={numberOfLines}
        placeholder={placeholder}
        {...otherProps}
      />
    </View>
  );
};

export default AppTextInput;

const styles = StyleSheet.create({
  from: {
    borderWidth: 2,
    borderColor: "gray",
    borderRadius: 10,
    marginVertical: 20,
    alignItems: "center",
    padding: 20,
    flexDirection: "row",
  },
  fromTxt: {
    color: "white",
    fontWeight: "bold",
    fontSize: 18,
  },
  locInput: {
    width: "90%",
    fontWeight: "bold",
    color: "white",
    fontSize: 20,
    paddingRight: 5,
  },
});
