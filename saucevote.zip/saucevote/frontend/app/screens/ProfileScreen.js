import React, {createRef, useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
  Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import BottomSheet from 'reanimated-bottom-sheet';
import Animated from 'react-native-reanimated';
import storage from '../auth/storage';
import recognize from '../api/recognize';

const ProfileScreen = () => {
  const bs = createRef();
  const fall = new Animated.Value(1);
  const [uid, setUid] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const [imageSrc, setimageSrc] = useState();
  const [message, setMessage] = useState('');

  useEffect(() => {
    getId();
  }, []);

  useEffect(() => {
    (async () => {
      if (Platform.OS !== 'web') {
        const {status} =
          await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
          alert('Sorry, we need camera roll permissions to make this work!');
        }
      }
    })();
  }, []);

  const getId = async () => {
    const user = await storage.getUser();
    setUid(user.id);
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      base64: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setimageSrc(result.uri);
      try {
        setIsLoading(true);
        const res = await recognize.enroll(uid, result.base64);
        setIsLoading(false);
        setMessage(res.message);
      } catch (error) {
        console.log('this too', error);
      }

      // const data = {
      //   SubscriptionKey: 'cf6174e269904783b0efe1f3298a9d8e',
      //   SampleName: 'voters',
      //   UniqueId: uid,
      //   SampleImages: {sampleNumber: result.base64},
      // };

      // try {
      //   const res = await image.post('/enroll', data, {
      //     headers: {
      //       'content-type': 'application/json',
      //       'x-rapidapi-key':
      //         '1912477eb1mshb0cc45c3cda0331p1740ffjsnb718647bc85f',
      //       'x-rapidapi-host': 'sacinta-face-recognition.p.rapidapi.com',
      //     },
      //   });
      //   if (res) {
      //     setIsLoading(false);
      //     setMessage(res.data.StatusMessage);
      //   } else {
      //     setIsLoading(false);
      //   }
      // } catch (error) {
      //   setIsLoading(false);
      // }
    }
  };

  const renderInner = () => (
    <View
      style={{
        backgroundColor: 'tomato',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
      }}>
      <Text
        style={{
          fontWeight: 'bold',
          color: 'white',
          fontSize: 20,
        }}>
        Take picture
      </Text>
      <View style={{height: '100%', paddingTop: 20}}>
        <TouchableOpacity
          onPress={pickImage}
          style={{
            height: 50,
            width: 300,
            padding: 10,
            backgroundColor: 'white',
            justifyContent: 'center',
            alignItems: 'center',
            elevation: 10,
          }}>
          <Text style={{fontWeight: 'bold', fontSize: 20}}>Take Photo</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => bs.current.snapTo(1)}
          style={{
            height: 50,
            width: 300,
            padding: 10,
            backgroundColor: 'white',
            justifyContent: 'center',
            alignItems: 'center',
            elevation: 10,
            marginVertical: 20,
          }}>
          <Text style={{fontWeight: 'bold', fontSize: 20}}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderhead = () => (
    <View
      style={{
        backgroundColor: 'tomato',
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        padding: 10,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <View>
        <View>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'white',
              fontSize: 20,
            }}>
            Face Scanner
          </Text>
        </View>
      </View>
    </View>
  );
  return (
    <View style={styles.ctn}>
      {isLoading ? (
        <View style={{alignSelf: 'center'}}>
          <ActivityIndicator size="large" color="tomato" />
        </View>
      ) : (
        <>
          <BottomSheet
            ref={bs}
            snapPoints={[330, 0]}
            initialSnap={1}
            enabledGestureInteraction={true}
            callbackNode={fall}
            renderContent={renderInner}
            renderHeader={renderhead}
          />
          <Animated.View
            style={{
              margin: 20,
              opacity: Animated.add(0.1, Animated.multiply(fall, 1.0)),
            }}>
            <View style={styles.header}>
              <Text style={{fontSize: 20, fontWeight: 'bold'}}>
                FACIAL RECOGNITON ENROLLMENT, PLEASE REGISTER YOUR FACE IF YOU
                HAVE NOT REGISTERED BEFORE.
              </Text>
            </View>
            <View>
              <TouchableOpacity
                style={styles.imgInput}
                onPress={() => bs.current.snapTo(0)}>
                <Icon name={'plus'} color="white" size={40} />
              </TouchableOpacity>
              {message === 'Enrolled 1 of 1 Images' ? (
                <Text
                  style={{fontSize: 20, color: 'green', alignSelf: 'center'}}>
                  REGISTRATION SUCCESSFUL! PROCEED TO HOMESCREEN TO BEGIN
                  VOTING.
                </Text>
              ) : (
                <Text style={{fontSize: 20, color: 'red', alignSelf: 'center'}}>
                  {message && message + ' !'}
                </Text>
              )}

              <Image
                style={{
                  height: 400,
                  width: 400,
                  borderRadius: 400,
                  alignSelf: 'center',
                }}
                resizeMode="contain"
                source={{uri: imageSrc}}
              />
            </View>
          </Animated.View>
        </>
      )}
    </View>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: 'white',
    // justifyContent: 'center',
    // alignItems: 'center',
  },
  header: {
    borderWidth: 2,
    padding: 10,
    borderColor: 'tomato',
  },
  imgInput: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: 'tomato',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
    alignSelf: 'center',
  },
});
