import React, { useRef, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import DropDownPicker from "react-native-dropdown-picker";
import { Picker } from "@react-native-picker/picker";
const TestScreen = () => {
  const [pickedValue, setPickedValue] = useState();
  const [togglePicker, setTogglePicker] = useState(false);

  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(null);
  const [items, setItems] = useState([
    {
      label: "Ikeja",
      value: "ikeja",
      selectable: true,
    },
    {
      label: "Mowe",
      value: "mowe",
      selectable: true,
    },
    {
      label: "Ajah",
      value: "ajah",
      selectable: true,
    },
    {
      label: "Ikota",
      value: "ikota",
      selectable: true,
    },
    {
      label: "Ikoyi",
      value: "ikoyi",
      selectable: true,
    },
    {
      label: "Ikate",
      value: "ikate",
      selectable: true,
    },
    {
      label: "Badore",
      value: "badore",
      selectable: true,
    },
    {
      label: "Epe",
      value: "epe",
      selectable: true,
    },
    {
      label: "Akoka",
      value: "akoka",
      selectable: true,
    },
    {
      label: "Oshodi",
      value: "oshodi",
      selectable: true,
    },
  ]);

  const testFiles = [
    {
      label: "Item1",
      value: "Item1",
    },
    {
      label: "Item2",
      value: "Item2",
    },
    {
      label: "Item3",
      value: "Item3",
    },
  ];

  return (
    <View style={styles.ctn}>
      <DropDownPicker
        open={togglePicker}
        value={pickedValue}
        dropDownContainerStyle={{ backgroundColor: "#354654" }}
        closeAfterSelecting={true}
        placeholder="Choose Area"
        onPress={() => setTogglePicker(!togglePicker)}
        setValue={(v) => setPickedValue(v)}
        items={[
          {
            label: "Item1",
            value: "Item1",
          },
          {
            label: "Item2",
            value: "Item2",
          },
          {
            label: "Item3",
            value: "Item3",
          },
        ]}
      />
      <Picker
        mode="dropdown"
        onValueChange={(itemValue, itemIndex) => setPickedValue(itemValue)}
      >
        {testFiles.map((testFile) => (
          <Picker.Item
            label={testFile.label.toString()}
            value={testFile.value.toString()}
            key={testFile.value.toString()}
            // color="black"
          />
        ))}
        <Picker.Item label="Java" value="java" />
        <Picker.Item label="JavaScript" value="js" />
      </Picker>
    </View>
  );
};

export default TestScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
});
