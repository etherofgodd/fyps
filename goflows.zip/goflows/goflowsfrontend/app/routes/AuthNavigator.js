import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import LoginScreen from "../screens/LoginScreen";
import SignupScreen from "../screens/SignupScreen";

const { Navigator, Screen } = createStackNavigator();
const AuthNavigator = () => {
  return (
    <Navigator initialRouteName="Login" mode="modal">
      <Screen
        name="Login"
        component={LoginScreen}
        options={{ headerShown: false }}
      />
      <Screen
        name="Signup"
        component={SignupScreen}
        options={{ headerShown: false }}
      />
    </Navigator>
  );
};

export default AuthNavigator;
