import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';
import VerifyScreen from '../screens/auth/VerifyScreen';
import VerifyMessageScreen from '../screens/auth/VerifyMessageScreen';

const {Navigator, Screen} = createStackNavigator();

const AuthNavigator = () => {
  return (
    <Navigator>
      <Screen
        name="LoginScreen"
        component={LoginScreen}
        options={{headerShown: false}}
      />
      <Screen
        name="VerifyScreen"
        component={VerifyScreen}
        options={{headerShown: false}}
      />
      <Screen
        name="RegisterScreen"
        component={RegisterScreen}
        options={{headerShown: false}}
      />
      <Screen
        name="VerifyMessage"
        component={VerifyMessageScreen}
        options={{headerShown: false}}
      />
    </Navigator>
  );
};

export default AuthNavigator;
