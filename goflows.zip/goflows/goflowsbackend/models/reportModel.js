import mongoose from "mongoose";

const reportSchema = new mongoose.Schema(
  {
    location: {
      type: "String",
      required: true,
    },

    startFrom: {
      type: String,
      required: true,
    },

    startTo: {
      type: String,
      required: true,
    },

    altFrom: {
      type: String,
    },

    altTo: {
      type: String,
    },

    desc: {
      type: String,
    },

    user: {
      type: mongoose.Types.ObjectId,
      ref: "User",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const Report = mongoose.model("Report", reportSchema);

export default Report;
