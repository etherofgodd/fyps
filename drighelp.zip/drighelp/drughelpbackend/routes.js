import express from "express";
import {
  authUser,
  createUser,
  getUserProfile,
  getUsers,
} from "./controllers/userController.js";
import {
  createDrug,
  getDrugById,
  getDrugs,
} from "./controllers/drugController.js";
import { protect } from "./middlewares/authMiddleware.js";
import { addAddiction } from "./controllers/addictionsController.js";

export default (app) => {
  const apiRoutes = express.Router();
  const authRoutes = express.Router();
  const drugRoutes = express.Router();
  const addictionRoutes = express.Router();
  app.use(express.json());
  app.use(
    express.urlencoded({
      extended: true,
    })
  );

  apiRoutes.use("/auth", authRoutes);
  apiRoutes.use("/drug", drugRoutes);
  apiRoutes.use("/addiction", addictionRoutes);

  //   Home route
  app.get("/", (req, res) =>
    res.json({
      note: "Welcome",
      message: "Cold turkey diagnosis",
    })
  );

  // Auth Routes
  authRoutes.route("/users").get(getUsers).post(createUser);
  authRoutes.route("/login").post(authUser);
  authRoutes.route("/profile").get(protect, getUserProfile);

  // Drug Routes
  drugRoutes.route("/create").post(createDrug);
  drugRoutes.route("/").get(getDrugs);
  drugRoutes.route("/single/:drugId").get(getDrugById);

  // Addiction

  addictionRoutes.route("/").post(protect, addAddiction);
  return app.use("/api", apiRoutes);
};
