import React from 'react';
import {createDrawerNavigator} from '@react-navigation/drawer';

import DrawerContents from '../components/DrawerContents';
import FeedNavigator from './FeedNavigator';
import ProfileScreen from '../screens/ProfileScreen';

const Drawer = createDrawerNavigator();

const AppNavigator = () => {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      drawerContent={props => <DrawerContents {...props} />}>
      <Drawer.Screen name="Feed" component={FeedNavigator} />
      <Drawer.Screen name="Profile" component={ProfileScreen} />
    </Drawer.Navigator>
  );
};

export default AppNavigator;
