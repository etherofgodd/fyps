import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import WelcomScreen from '../screens/WelcomScreen';

const {Navigator, Screen} = createStackNavigator();

const AuthNavigator = () => {
  return (
    <Navigator>
      <Screen
        name="SplashScreen"
        component={WelcomScreen}
        options={{headerShown: false}}
      />
      <Screen
        name="LoginScreen"
        component={LoginScreen}
        options={{headerShown: false}}
      />
      <Screen
        name="RegisterScreen"
        component={RegisterScreen}
        options={{headerShown: false}}
      />
    </Navigator>
  );
};

export default AuthNavigator;
