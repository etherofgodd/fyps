import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  AppForm,
  AppFormField,
  ErrorMessage,
  SubmitButton,
} from '../../components/forms';
import * as Yup from 'yup';
import {logInUser} from '../../auth/authentication';

const validationSchema = Yup.object().shape({
  email: Yup.string().required().email().label('Email'),
  password: Yup.string().required().min(6).label('Password'),
});

const LoginScreen = ({navigation}) => {
  const [errorMessage, setErrorMessage] = useState();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async ({email, password}) => {
    console.log({email, password});

    setIsLoading(true);
    const message = await logInUser(email, password);
    if (message) {
      setErrorMessage(message);
    }
    setIsLoading(false);
  };

  const [secure, setSecure] = useState(true);

  const toggleEye = () => {
    setSecure(!secure);
    console.log(secure);
  };
  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#0C2D48" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={{flex: 1, backgroundColor: 'white'}}>
        <View style={styles.container}>
          <View style={styles.iconCircle}>
            <Icon name="ballot" color="#0C2D48" size={200} />
          </View>
          <View>
            <View>
              <Text
                style={{fontWeight: 'bold', fontSize: 20, color: '#0C2D48'}}>
                Sign In
              </Text>
            </View>
            <AppForm
              initialValues={{email: '', password: ''}}
              onSubmit={handleSubmit}
              validationSchema={validationSchema}>
              <ErrorMessage error={errorMessage} visible={errorMessage} />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                name="email"
                placeholder="Email"
                textContentType="emailAddress"
                color="black"
                iconLeft="email"
                style={{flex: 1, fontWeight: 'bold'}}
              />
              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                iconLeft="lock"
                iconRight={secure ? 'eye' : 'eye-off'}
                name="password"
                color="black"
                placeholder="password"
                iconRightPress={toggleEye}
                secureTextEntry={secure}
                textContentType="password"
                style={{flex: 1, fontWeight: 'bold'}}
              />
              <SubmitButton title="Sign In" loading={isLoading} />
            </AppForm>
          </View>
          <View style={styles.info}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <View style={styles.line} />
              <Text style={{fontWeight: 'bold', fontSize: 20}}>Or</Text>
              <View style={styles.line} />
            </View>
            <View style={styles.authAct}>
              <TouchableOpacity
                onPress={() => navigation.navigate('VerifyScreen')}>
                <Text style={styles.txt}>Sign Up</Text>
              </TouchableOpacity>
              <TouchableOpacity>
                <Text style={styles.txt}>About</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    padding: 20,
  },
  info: {
    marginTop: 15,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },

  iconCircle: {
    borderWidth: 2,
    width: 230,
    height: 230,
    borderRadius: 115,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#0C2D48',
    elevation: 2,
    backgroundColor: 'white',
    marginBottom: 20,
  },
  line: {
    borderWidth: 1,
    width: 100,
    height: 1,
    backgroundColor: '#0C2D48',
    marginHorizontal: 9,
    borderColor: '#0C2D48',
  },
  authAct: {
    height: 90,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  txt: {
    fontWeight: 'bold',
    fontSize: 20,
  },
});
