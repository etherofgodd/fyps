import client from './client';

export default vote = (election_Id, userId, candidateId, voterId) =>
  client.post(`/vote/${election_Id}`, {
    userId,
    candidateId,
    voterId,
  });
