import DrugsScreen from "./DrugsScreen";

const Home = () => {
  return (
    <div>
      <div className="app">
        <div>
          <DrugsScreen />
        </div>
      </div>
    </div>
  );
};

export default Home;
