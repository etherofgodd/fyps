import { create } from "apisauce";
import storage from "../auth/storage";
import settings from "../config/settings";

const apiClient = create({
  baseURL: settings.apiUrl,
});

apiClient.addAsyncRequestTransform(async (request) => {
  const authToken = await storage.getToken();
  if (!authToken) return;
  request.headers["authorization"] = "Bearer " + authToken;
});

export default apiClient;
