import React, {useEffect} from 'react';
import {StyleSheet, Text, View, ActivityIndicator} from 'react-native';
import {DrawerItem, DrawerContentScrollView} from '@react-navigation/drawer';
import {useDispatch, useSelector} from 'react-redux';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {logOut, getUserDetails} from '../redux/actions/userActions';

const DrawerContents = props => {
  const dispatch = useDispatch();
  const {loading, error, user} = useSelector(state => state.userDetails);

  useEffect(() => {
    dispatch(getUserDetails());
  }, [dispatch]);

  return (
    <View style={styles.overallView}>
      <DrawerContentScrollView {...props}>
        <View style={styles.drawerContent}>
          <View style={styles.userInfoSection}>
            <View style={styles.profileViewCtn}>
              <Icon name={'account'} size={100} color="tomato" />
            </View>
            <View style={styles.profileDetsInfo}>
              {loading && <ActivityIndicator size="small" color="tomato" />}
              <Text style={{fontSize: 20, color: '#000', fontWeight: 'bold'}}>
                {user && user.name}
              </Text>
              <Text
                style={{
                  fontSize: 20,
                  color: 'gray',
                  fontWeight: 'bold',
                  fontStyle: 'italic',
                }}>
                {user && user.voterId}
              </Text>
              <Text style={{color: 'red'}}>{error && error}</Text>
            </View>
          </View>

          <View style={styles.divider} />

          <DrawerItem
            icon={({size, color}) => (
              <Icon name="home" color={color} size={size} />
            )}
            label="Home"
            onPress={() => {
              props.navigation.navigate('Feed');
            }}
          />

          <View style={styles.divider} />

          <DrawerItem
            icon={({size, color}) => (
              <Icon name="account" color={color} size={size} />
            )}
            label="Profile"
            onPress={() => {
              props.navigation.navigate('Profile');
            }}
          />

          <View style={styles.divider} />

          <DrawerItem
            icon={({size, color}) => (
              <Icon name="exit-to-app" color={color} size={size} />
            )}
            label="Log Out"
            onPress={() => dispatch(logOut())}
          />

          <View style={styles.divider} />
        </View>
      </DrawerContentScrollView>
    </View>
  );
};

export default DrawerContents;

const styles = StyleSheet.create({
  overallView: {
    flex: 1,
  },
  drawerContent: {
    flex: 1,
  },
  userInfoSection: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileViewCtn: {
    marginTop: 20,
    width: 200,
    borderRadius: 50,
    borderWidth: 2,
    borderColor: 'tomato',
    justifyContent: 'center',
    alignItems: 'center',
  },
  divider: {
    height: 2,
    width: '100%',
    backgroundColor: 'tomato',
    marginVertical: 10,
  },
  profileDetsInfo: {
    justifyContent: 'center',
    alignItems: 'center',
  },
});
