import React from 'react';
import {StyleSheet, TouchableOpacity, Text, View} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const CandidateCard = ({name, onPress, desc, party}) => {
  return (
    <View style={styles.card}>
      <View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <Icon name="account-outline" size={40} color="#0C2D48" />
          <Text style={{textTransform: 'uppercase', fontWeight: 'bold'}}>
            {party}
          </Text>
        </View>

        <View>
          <Text
            style={{
              textTransform: 'uppercase',
              fontWeight: 'bold',
              fontSize: 16,
            }}>
            {name}
          </Text>
        </View>
        <View>
          <Text style={{textTransform: 'uppercase', fontWeight: 'bold'}}>
            From: {desc}
          </Text>
        </View>
      </View>
      <TouchableOpacity style={styles.btn} onPress={onPress}>
        <Text style={{color: 'white', fontWeight: 'bold', fontSize: 18}}>
          Vote
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default CandidateCard;

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    padding: 20,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
    borderColor: '#0C2D48',
    borderRadius: 5,
  },
  btn: {
    padding: 10,
    backgroundColor: '#0C2D48',
    elevation: 3,
    borderRadius: 5,
  },
});
