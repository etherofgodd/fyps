import "./LoadingCtn.css";
export default function LoadingCtn() {
  return <div className="lds_dual_ring"></div>;
}
