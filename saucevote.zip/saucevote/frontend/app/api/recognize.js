import facialrecognition from './facialrecognition';

const enroll = async (uid, image) => {
  try {
    const data = {
      SubscriptionKey: 'cf6174e269904783b0efe1f3298a9d8e',
      SampleName: 'voters',
      UniqueId: uid,
      SampleImages: {sampleNumber: image},
    };
    const response = await facialrecognition.post('/enroll', data, {
      headers: {
        'content-type': 'application/json',
        'x-rapidapi-key': '1912477eb1mshb0cc45c3cda0331p1740ffjsnb718647bc85f',
        'x-rapidapi-host': 'sacinta-face-recognition.p.rapidapi.com',
      },
    });

    console.log(response);

    if (response.ok) {
      return {
        type: 'SUCCESS',
        message: response.data.StatusMessage,
      };
    } else {
      return {
        type: 'FAILED',
        message:
          response.problem === 'NETWORK_ERROR'
            ? 'NETWORK ERROR'
            : 'SERVER ERROR',
      };
    }
  } catch (error) {
    console.log('error in catch block', error);
  }
};

const recognize = async image => {
  try {
    const data = {
      SubscriptionKey: 'cf6174e269904783b0efe1f3298a9d8e',
      SampleImages: {sampleNumber: image},
    };
    const response = await facialrecognition.post('/recognize', data, {
      headers: {
        'content-type': 'application/json',
        'x-rapidapi-key': '1912477eb1mshb0cc45c3cda0331p1740ffjsnb718647bc85f',
        'x-rapidapi-host': 'sacinta-face-recognition.p.rapidapi.com',
      },
    });

    if (response.ok) {
      return {
        type: 'SUCCESS',
        message: response.data.StatusMessage,
      };
    } else {
      return {
        type: 'FAILED',
        message:
          response.problem === 'NETWORK_ERROR'
            ? 'NETWORK ERROR'
            : 'SERVER ERROR',
      };
    }
  } catch (error) {
    console.log('error in catch block', error);
  }
};
export default {
  enroll,
  recognize,
};
