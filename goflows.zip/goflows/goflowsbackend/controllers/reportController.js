import expressAsyncHandler from "express-async-handler";
import Report from "../models/reportModel.js";
import User from "../models/userModel.js";

// @desc get Reports
// @route GET /api/report/new
// @access public
export const createReport = expressAsyncHandler(async (req, res) => {
  const { location, altFrom, altTo, desc, startFrom, startTo } = req.body;

  console.log(req.body);

  if (!location || !startFrom || !startTo) {
    res.status(400).json({
      message: "Please Input the right input",
    });
    return;
  }

  const userExists = User.findById(req.user._id);

  if (!userExists) {
    return res.status(400).json({
      message: "Invalid User",
    });
  }

  const report = await Report.create({
    location,
    altFrom,
    altTo,
    desc,
    startFrom,
    startTo,
    user: req.user._id,
  });

  report &&
    res.status(201).json({
      message: "Report created successfully",
    });

  !report &&
    res.status(500).json({
      message: "Server error, Something happened",
    });
});

// @desc get Reports
// @route GET /api/report/
// @access public
export const getReports = expressAsyncHandler(async (req, res) => {
  const location = req.query.locs
    ? {
        location: req.query.locs,
      }
    : {};

  const searchKeyword = req.query.searchKeyword
    ? {
        desc: {
          $regex: req.query.searchKeyword,
          $options: "i",
        },
      }
    : {};

  const reports = await Report.find({ ...location, ...searchKeyword }).select(
    "-__v"
  );

  if (!reports || reports.length < 1) {
    return res.status(404).json({
      message: "No report found in the database",
    });
  } else {
    return res.status(200).json({
      reports,
    });
  }
});

// @desc get Reports for single user
// @route GET /api/reports/me
// @access private
export const getSingleUserReport = expressAsyncHandler(async (req, res) => {
  const userReport = await Report.findOne({ user: req.user._id });

  if (userReport) {
    return res.status(200).json({
      userReport,
    });
  } else if (!userReport || userReport.length < 1) {
    return res.status(404).json({
      message: "No report found",
    });
  }
});

// @desc get Reports by id
// @route GET /api/reports/:id
// @access public
export const getReportById = expressAsyncHandler(async (req, res) => {
  const id = req.params.report_id;

  const report = await Report.findById(id).select("-__v -updatedAt");

  if (!report) {
    return res.status(400).json({
      message: "report not found",
    });
  } else {
    return res.status(200).json({
      report,
    });
  }
});
