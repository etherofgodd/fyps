import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import "./App.css";
import Header from "./components/Header";
import Dashboard from "./screen/Dashboard";
import Help from "./screen/Help";
import HomeScreen from "./screen/HomeScreen";
import Map from "./screen/Map";
import SigninScreen from "./screen/SigninScreen";
import SignupScreen from "./screen/SigupScreen";

function App() {
  return (
    <div className="main_container">
      <Router>
        <div className="header">
          <Header />
        </div>
        <div className="main">
          <Switch>
            <Route path="/" exact={true}>
              <HomeScreen />
            </Route>
            <Route path="/signin">
              <SigninScreen />
            </Route>
            <Route path="/signup">
              <SignupScreen />
            </Route>
            <Route path="/help">
              <Help />
            </Route>
            <Route path="/dashbaord">
              <Dashboard />
            </Route>
            <Route path="/dashboard/map">
              <Map />
            </Route>
          </Switch>
        </div>
      </Router>
    </div>
  );
}

export default App;
