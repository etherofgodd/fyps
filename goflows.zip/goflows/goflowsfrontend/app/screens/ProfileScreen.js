import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Icon from "@expo/vector-icons/MaterialCommunityIcons";
import useAuth from "../auth/useAuth";

const ProfileScreen = ({ navigation }) => {
  const { logOut, user } = useAuth();

  return (
    <View style={styles.ctn}>
      <View
        style={{ borderBottomWidth: 2, borderColor: "white", marginTop: 20 }}
      >
        <Text style={{ color: "white", fontWeight: "bold", fontSize: 30 }}>
          Profile Screen
        </Text>
      </View>
      <View
        style={{
          padding: 15,
          backgroundColor: "#354654",
          borderRadius: 10,
          marginTop: 10,
        }}
      >
        <Text style={{ color: "white", fontWeight: "bold", fontSize: 20 }}>
          Reporting ID
        </Text>
        <Text style={{ color: "white", fontWeight: "bold" }}>
          {user && user.id}
        </Text>
      </View>
      <TouchableOpacity
        style={{
          padding: 15,
          backgroundColor: "#4268bc",
          borderRadius: 10,
          marginTop: 20,
        }}
        onPress={() => navigation.navigate("Me")}
      >
        <Text style={{ color: "white", fontWeight: "bold", fontSize: 20 }}>
          Reports
        </Text>
        <Text style={{ color: "white", fontWeight: "bold" }}>
          Click to view all your reports
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={{
          padding: 15,
          backgroundColor: "tomato",
          borderRadius: 10,
          marginTop: 20,
          flexDirection: "row",
          justifyContent: "space-between",
        }}
        onPress={() => logOut()}
      >
        <Text style={{ color: "white", fontWeight: "bold", fontSize: 20 }}>
          Log Out
        </Text>
        <Icon name="logout" color="white" size={30} />
      </TouchableOpacity>
    </View>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    padding: 10,
    backgroundColor: "#070606",
  },
});
