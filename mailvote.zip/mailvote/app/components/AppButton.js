import React from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
} from 'react-native';

const AppButton = ({btnName, onPress, color = '#0C2D48', loading}) => {
  return (
    <View>
      {loading ? (
        <ActivityIndicator size="large" color="#0C2D48" />
      ) : (
        <TouchableOpacity
          style={[styles.btn, {backgroundColor: color}]}
          onPress={onPress}>
          <Text style={[styles.btnText]}>{btnName}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

export default AppButton;

const styles = StyleSheet.create({
  btnText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  btn: {
    width: 300,
    height: 55,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'tomato',
    marginTop: 20,
    borderRadius: 10,
    elevation: 5,
    alignSelf: 'center',
  },
});
