import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Report from "../api/report";
import useApi from "../hooks/useApi";

const Me = () => {
  const [errorMessage, setErrorMessage] = useState();
  const [reports, setReports] = useState();
  const getMyReportApi = useApi(Report.getMe);

  useEffect(() => {
    getReports();
  }, []);

  const getReports = async () => {
    setErrorMessage();
    const result = await getMyReportApi.request();

    if (!result.ok) {
      if (result.data) setErrorMessage(result.data.message);
      else {
        setError(
          "An unexpected Error occurred. Kindly check your internet connection"
        );
        console.log(`result`, result);
      }
      return;
    }

    setReports(result.data.userReport);
  };

  return (
    <View style={styles.ctn}>
      <StatusBar backgroundColor="black" barStyle="light-content" />

      {/* <View>


        {getMyReportApi.loading && (
          <ActivityIndicator color="white" size="large" />
        )}

        {getMyReportApi.error && (
          <View>
            <Text>{errorMessage}</Text>
          </View>
        )}

        
      </View> */}

      {reports && (
        <FlatList
          data={reports}
          keyExtractor={(item) => item._id}
          renderItem={({ item }) => {
            console.log(item);
            console.log("i reached here");
            //   <TouchableOpacity style={{ marginVertical: 10 }}>
            //     <View style={styles.bump}>
            //       <Text
            //         style={{
            //           color: "white",
            //           fontSize: 20,
            //           textTransform: "uppercase",
            //           fontWeight: "bold",
            //         }}
            //       >
            //         {item.location}
            //       </Text>
            //     </View>
            //     <View style={styles.card}>
            //       <View>
            //         <Text
            //           style={{
            //             color: "white",
            //             fontSize: 20,
            //             fontWeight: "bold",
            //           }}
            //         >
            //           From: {item.startFrom}
            //         </Text>
            //       </View>
            //       <View>
            //         <Text
            //           style={{
            //             color: "white",
            //             fontSize: 20,
            //             fontWeight: "bold",
            //           }}
            //         >
            //           To:{item.startTo}
            //         </Text>
            //       </View>

            //       <View>
            //         <Text
            //           style={{
            //             color: "white",
            //             fontSize: 20,
            //             fontWeight: "bold",
            //           }}
            //         >
            //           Time: {formatDate(item.createdAt)}
            //         </Text>
            //       </View>
            //     </View>
            //   </TouchableOpacity>
          }}
        />
      )}
    </View>
  );
};

export default Me;

const styles = StyleSheet.create({
  ctn: {
    backgroundColor: "#070606",
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  card: {
    backgroundColor: "#354654",
    borderTopRightRadius: 10,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    justifyContent: "space-between",
    padding: 10,
    height: 150,
  },
  bump: {
    padding: 10,
    width: 100,
    backgroundColor: "#354654",
    borderTopEndRadius: 10,
    borderTopLeftRadius: 10,
    borderBottomWidth: 3,
  },
});
