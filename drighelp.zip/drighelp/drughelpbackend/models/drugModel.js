import mongoose from "mongoose";

const drugSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    unique: true,
  },

  info: {
    type: String,
    required: true,
  },

  effects: {
    info: {
      type: String,
      required: true,
    },

    effects: [
      {
        type: String,
        required: true,
      },
    ],
  },

  addiction: {
    info: {
      type: String,
      required: true,
    },
    signs: [
      {
        sign: {
          type: String,
          required: true,
        },

        stage: {
          type: String,
          required: true,
        },
      },
    ],
  },
});

const Drug = mongoose.model("Drug", drugSchema);

export default Drug;
