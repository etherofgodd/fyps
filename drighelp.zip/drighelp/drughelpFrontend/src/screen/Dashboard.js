import axios from "axios";
import { useEffect, useState } from "react";
import "./Dashboard.css";
import { Link } from "react-router-dom";

function Dashboard() {
  const [user, setUser] = useState();
  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!token) {
      window.location.replace("/signin");
    }
    getUserProfile(token);
  }, []);

  const getUserProfile = async (token) => {
    try {
      const data = await axios.get("http://localhost:10000/api/auth/profile", {
        headers: {
          authorization: "Bearer " + token,
        },
      });
      setUser(data.data);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div style={{ color: "white" }}>
      <div>
        <h2>Welcome {user && user.user.email}</h2>
      </div>
      <div>
        <h2>Meta Data</h2>
        <div>
          <table className="table">
            <thead>
              <th>Drug</th>
              <th>Diagnosis</th>
              <th>Notes</th>
            </thead>
            <tbody>
              {user &&
                user.addiction.map((addict) => (
                  <tr key={addict._id}>
                    <td data-label="Drug">{addict.drug}</td>
                    <td data-label="Stage">{addict.stage}</td>
                    <td data-label="Notes">
                      {addict.stage === "Beginning Stage" ? (
                        "You are still at the beginning stages, Please Stop!"
                      ) : addict.stage === "Mild abuser" ? (
                        "It's not too late to stop! please stop"
                      ) : (
                        <Link className="map_color" to="/dashboard/map">
                          Please see the map, for directions to a rehab center.
                          YOU NEED HELP
                        </Link>
                      )}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
