import * as React from 'react';
import {NavigationContainer} from '@react-navigation/native';
// import auth from '@react-native-firebase/auth';

import AppNavigator from './app/routes/AppNavigator';
import AuthNavigator from './app/routes/AuthNavigator';
import {auth} from './app/config/firebaseconnect';

export default function App() {
  const [initializing, setInitializing] = React.useState(true);
  const [user, setUser] = React.useState();

  function onAuthStateChanged(user) {
    setUser(user);
    if (initializing) setInitializing(false);
  }

  React.useEffect(() => {
    const subscriber = auth.onAuthStateChanged(onAuthStateChanged);
    return subscriber; // unsubscribe on unmount
  }, []);

  if (initializing) return null;

  return (
    <>
      <NavigationContainer>
        {!user ? <AuthNavigator /> : <AppNavigator />}
      </NavigationContainer>
    </>
  );
}
