import React from 'react';
import {
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const WelcomScreen = ({navigation}) => {
  return (
    <View style={styles.ctn}>
      <StatusBar backgroundColor="tomato" />
      <Text style={styles.ctnText}> Sauce vote 🔥</Text>

      <TouchableOpacity
        style={styles.proceedText}
        onPress={() => {
          navigation.navigate('LoginScreen');
        }}>
        <Text
          style={{
            color: 'tomato',
            textTransform: 'uppercase',
            fontWeight: 'bold',
          }}>
          Proceed
        </Text>
        <Icon
          name="arrow-right"
          size={20}
          style={{paddingLeft: 10}}
          color="tomato"
        />
      </TouchableOpacity>
    </View>
  );
};

export default WelcomScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'tomato',
  },
  ctnText: {
    fontSize: 35,
    fontWeight: 'bold',
    color: 'white',
  },
  proceedText: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 3,
    elevation: 3,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
