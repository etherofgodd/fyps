import axios from "axios";
import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import "./SigupScreen.css";

const SignupScreen = () => {
  const emailInput = useRef();
  const passwordInput = useRef();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState();

  const signin = async (e) => {
    e.preventDefault();
    const email = emailInput.current.value;
    const password = passwordInput.current.value;

    try {
      setLoading(true);
      setError(undefined);
      await axios.post("http://localhost:10000/api/auth/users", {
        email,
        password,
      });
      window.location.replace("/signup");
    } catch (error) {
      setLoading(false);
      setError(error.response.data.message);
    }
  };
  return (
    <div className="signup">
      <div className="signup_container">
        <form onSubmit={signin}>
          <div className="signup_name">
            <h2>Get Help !</h2>
          </div>
          {error && (
            <div
              style={{
                fontWeight: "bolder",
                fontSize: "20px",
                color: "red",
                textAlign: "center",
              }}
            >
              {error}
            </div>
          )}
          <div className="signup_form">
            <div className="signup_label">
              <label htmlFor="name">Enter Your Email</label>
            </div>
            <div>
              <input
                type="text"
                name="name"
                id="name"
                required
                ref={emailInput}
                className="input"
              />
            </div>
            <div className="signup_label">
              <label htmlFor="password">Enter Password</label>
            </div>
            <div>
              <input
                type="password"
                name="password"
                id="password"
                ref={passwordInput}
                required
                className="input"
              />
            </div>
            {loading ? (
              <div className="lds_dual_ring"></div>
            ) : (
              <button ton className="form_btn">
                Sign Up
              </button>
            )}
          </div>
        </form>
        <div className="signup_link">
          <div>
            <h4>Do you already have an account ?</h4>
          </div>
          <div>
            <Link to="/signin" className="link">
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignupScreen;
