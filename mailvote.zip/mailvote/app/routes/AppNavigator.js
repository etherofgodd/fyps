import React from 'react';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {createMaterialBottomTabNavigator} from '@react-navigation/material-bottom-tabs';
import ProfileScren from '../screens/ProfileScren';
import VoteNavigator from './VoteNavigator';

const Tab = createMaterialBottomTabNavigator();

const AppNavigator = () => {
  return (
    <Tab.Navigator barStyle={{backgroundColor: '#0C2D48'}}>
      <Tab.Screen
        name="Home"
        component={VoteNavigator}
        options={{
          tabBarIcon: ({color}) => (
            <Icon name="ballot" size={20} color={color} />
          ),
        }}
      />

      <Tab.Screen
        name="Profile"
        component={ProfileScren}
        options={{
          tabBarIcon: ({color, focused}) => (
            <Icon name="account" size={20} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
};

export default AppNavigator;
