import mongoose from "mongoose";
const { Schema, model } = mongoose;

const addictionSchema = new Schema({
  drug: {
    type: String,
    required: true,
  },
  stage: {
    type: String,
    required: true,
  },
  user: {
    type: mongoose.Types.ObjectId,
    ref: "User",
  },
});

const Addiction = model("Addiction", addictionSchema);

export default Addiction;
