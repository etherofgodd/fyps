// import '@react-native-firebase/app';
import fireAuth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

export const db = firestore();
export const auth = fireAuth();
