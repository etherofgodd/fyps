import client from "./client";

const register = (email, password) =>
  client.post("/auth/users", { email, password });

export default register;
