import React, {useEffect, useState} from 'react';
import {
  Button,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import Appcard from '../components/Appcard';
import {db, auth} from '../config/firebaseconnect';

const HomeScreen = ({navigation}) => {
  const [polls, setPolls] = useState([]);

  useEffect(() => {
    getPolls();
  }, []);

  const name = auth.currentUser.displayName;

  const getPolls = async () => {
    try {
      const pollDoc = await db.collection('poll').get();
      let polls = [];
      pollDoc.forEach(doc => {
        polls.push(...[doc.data()]);
        // console.log(doc.id, doc.data());
      });
      setPolls(polls);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <View style={styles.ctn}>
      <View style={{marginTop: 10, borderBottomWidth: 2}}>
        <Text style={{fontSize: 18, fontWeight: 'bold'}}>
          Welcome{'  '}
          <Text style={{fontSize: 20, textTransform: 'capitalize'}}>
            {name}{' '}
          </Text>
          😄
        </Text>
      </View>

      <FlatList
        data={polls}
        key={({item}) => item.poll_id}
        renderItem={({item}) => {
          console.log(item.poll_id);
          return (
            <Appcard
              title={item.title}
              count={item.count.length}
              key={item.poll_id}
              onPress={() => navigation.navigate('Candidates', item)}
            />
          );
        }}
      />
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: 'white',
    padding: 10,
  },
});
