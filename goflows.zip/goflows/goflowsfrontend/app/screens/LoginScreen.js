import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  TextInput,
  View,
  Dimensions,
  TouchableOpacity,
} from "react-native";
import * as Yup from "yup";

// components
import AuthFormField from "../components/auth/AuthFormField";
import SubmitButton from "../components/auth/SubmitBtn";
import AppForm from "../components/forms/AppForm";
import ErrorMessage from "../components/forms/ErrorMesage";

// helpers
import useAuth from "../auth/useAuth";
import login from "../api/login";
import useApi from "../hooks/useApi";
const validationSchema = Yup.object().shape({
  email: Yup.string().required().email().label("Email"),
  password: Yup.string().required().min(4).label("Password"),
});
const LoginScreen = ({ navigation }) => {
  const loginApi = useApi(login);
  const auth = useAuth();
  const [error, setError] = useState();

  const handleSubmit = async ({ email, password }) => {
    const result = await loginApi.request(email, password);

    if (!result.ok) {
      if (result.data) setError(result.data.message);
      else {
        setError(
          "An unexpected Error occurred. Kindly check your internet connection"
        );
        console.log(`result`, result);
      }
      return;
    }

    auth.logIn(result.data.token);
  };
  return (
    <View style={styles.ctn}>
      <StatusBar style="light" />
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          marginVertical: 10,
        }}
      >
        <Text
          style={{
            fontWeight: "bold",
            fontSize: 20,
            color: "white",
            marginVertical: 10,
          }}
        >
          Welcome Back !
        </Text>
        <Text style={{ fontWeight: "700", fontSize: 14, color: "gray" }}>
          Please sign in to your account
        </Text>
      </View>

      <AppForm
        initialValues={{
          email: "",
          password: "",
        }}
        onSubmit={handleSubmit}
        validationSchema={validationSchema}
      >
        <ErrorMessage error={error} visible={error} />

        <AuthFormField
          name="email"
          placeholder="EMAIL"
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="email-address"
          name="email"
          textContentType="emailAddress"
        />

        <AuthFormField
          autoCapitalize="none"
          autoCorrect={false}
          name="password"
          placeholder="PASSWORD"
          secureTextEntry
          textContentType="password"
        />
        <View style={{ alignSelf: "flex-end", paddingRight: 20 }}>
          <Text style={{ color: "gray" }}>Forgot Password ?</Text>
        </View>

        <SubmitButton btnName="SIGN IN" loading={loginApi.loading} />
      </AppForm>

      <View style={{ justifyContent: "center", flexDirection: "row" }}>
        <Text style={{ color: "white", fontWeight: "900" }}>
          Don't have an account ?{" "}
        </Text>
        <TouchableOpacity onPress={() => navigation.navigate("Signup")}>
          <Text style={{ color: "skyblue", fontWeight: "900" }}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#070606",
    padding: 10,
  },
});
