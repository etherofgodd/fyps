import React from 'react';
import {TouchableOpacity, StyleSheet, Text, View} from 'react-native';

const Appcard = ({title, count, onPress}) => {
  return (
    <View style={styles.card}>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <View style={{padding: 10, width: '60%'}}>
          <Text
            style={{
              flexWrap: 'wrap',
              fontWeight: 'bold',
              fontSize: 20,
              textTransform: 'capitalize',
            }}>
            {title}
          </Text>
        </View>
        <TouchableOpacity
          style={{
            padding: 10,
            backgroundColor: '#0C2D48',
            borderRadius: 10,
            elevation: 2,
            width: '40%',
          }}
          onPress={onPress}>
          <Text style={{color: 'white', fontWeight: 'bold', fontSize: 18}}>
            View Candidates
          </Text>
        </TouchableOpacity>
      </View>
      <View>
        <Text
          style={{
            flexWrap: 'wrap',
            fontWeight: 'bold',
            fontSize: 20,
            textTransform: 'capitalize',
          }}>
          Number of votes = {count}
        </Text>
      </View>
    </View>
  );
};

export default Appcard;

const styles = StyleSheet.create({
  card: {
    borderWidth: 2,
    borderColor: '#0C2D48',
    marginVertical: 10,
    padding: 10,
  },
});
