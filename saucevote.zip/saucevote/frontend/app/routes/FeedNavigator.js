import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import CandidateScreen from '../screens/CandidateScreen';
import VoteScreen from '../screens/VoteScreen';
import AuthuserScreen from '../screens/AuthuserScreen';

const {Navigator, Screen} = createStackNavigator();

const FeedNavigator = () => {
  return (
    <Navigator initialRouteName="Home" screenOptions={{headerShown: false}}>
      <Screen name="Home" component={HomeScreen} />
      <Screen
        name="Candidates"
        component={CandidateScreen}
        options={{headerShown: true, headerTintColor: 'tomato'}}
      />
      <Screen
        name="Authenticate"
        component={AuthuserScreen}
        options={{headerShown: true, headerTintColor: 'tomato'}}
      />
      <Screen
        name="VoteScreen"
        component={VoteScreen}
        options={{headerShown: true, headerTintColor: 'tomato'}}
      />
    </Navigator>
  );
};

export default FeedNavigator;
