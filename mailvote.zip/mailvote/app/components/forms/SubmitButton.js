import React from 'react';
import {useFormikContext} from 'formik';
import AppButton from '../AppButton';

const SubmitButton = ({title, loading}) => {
  const {handleSubmit} = useFormikContext();
  return <AppButton btnName={title} onPress={handleSubmit} loading={loading} />;
};

export default SubmitButton;
