import axios from "axios";
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import LoadingCtn from "../components/LoadingCtn";
import "./SigninScreen.css";

const SigninScreen = () => {
  const emailInput = useRef();
  const passwordInput = useRef();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState();

  const signin = async (e) => {
    e.preventDefault();
    const email = emailInput.current.value;
    const password = passwordInput.current.value;

    try {
      setLoading(true);
      setError(undefined);
      const response = await axios.post(
        "http://localhost:10000/api/auth/login",
        {
          email,
          password,
        }
      );
      const token = response.data.token;
      localStorage.setItem("token", token);

      window.location.replace("/dashbaord");

      setLoading(false);
    } catch (error) {
      setLoading(false);
      setError(error.response.data.message);
    }
  };
  return (
    <div className="signin">
      <div className="signin_container">
        <form onSubmit={signin}>
          <div className="signin_form">
            {error && (
              <div
                style={{
                  fontWeight: "bolder",
                  fontSize: "20px",
                  color: "red",
                  textAlign: "center",
                }}
              >
                {error}
              </div>
            )}
            <div className="signin_label">
              <label htmlFor="name">Enter Your Email</label>
            </div>
            <div>
              <input
                type="email"
                name="email"
                id="email"
                required
                ref={emailInput}
                className="input"
              />
            </div>
            <div className="signin_label">
              <label htmlFor="password">Enter Password</label>
            </div>
            <div>
              <input
                type="password"
                name="password"
                id="password"
                ref={passwordInput}
                required
                className="input"
              />
            </div>
            {loading ? (
              <LoadingCtn />
            ) : (
              <button className="form_btn">Sign in</button>
            )}
          </div>
        </form>
        <div className="signin_link">
          <div>
            <h4>Don't have an account ?</h4>
          </div>
          <div>
            <Link to="/signup" className="link">
              Sign Up
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SigninScreen;
