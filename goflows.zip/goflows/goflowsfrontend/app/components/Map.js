import React, { useEffect, useState } from "react";
import { StyleSheet, Text, View, Dimensions, Image } from "react-native";
import * as Location from "expo-location";
import MapView, { Callout, Marker } from "react-native-maps";
import MapViewDirections from "react-native-maps-directions";
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete";
const { width, height } = Dimensions.get("window");
const ASPECT_RATIO = width / height;
const latitudeDelta = 0.0922;
const longitudeDelta = latitudeDelta * ASPECT_RATIO;

const Map = () => {
  const [location, setLocation] = useState({
    latitude: 6.5244,
    longitude: 3.3792,
    latitudeDelta: 0.0043,
    longitudeDelta: 0.0034,
  });
  const [destination, setDestination] = useState({
    latitude: 0.0,
    longitude: 0.0,
  });
  const [errorMessage, setErrorMessage] = useState("");

  const getLocation = async () => {
    let { status } = await Location.requestPermissionsAsync();
    if (status !== "granted") {
      setErrorMessage("Permission to access Location Was DENIED");
    }
    let area = await Location.getCurrentPositionAsync({});
    let lat = parseFloat(area.coords.latitude);
    let lon = parseFloat(area.coords.longitude);

    setLocation({
      latitude: lat,
      longitude: lon,
      latitudeDelta: 0.0023,
      longitudeDelta: 0.0014,
    });
  };

  useEffect(() => {
    getLocation();
  });
  return (
    <>
      <View>
        <MapView
          style={styles.map}
          initialRegion={location}
          showsUserLocation={true}
          zoomEnabled={true}
        >
          <Marker
            coordinate={location}
            title="Bus"
            image={require("../../assets/icons8-bus-80.png")}
          ></Marker>
          {destination.latitude && destination.longitude > 0 ? (
            <MapViewDirections
              apikey="AIzaSyAreXK8Y8iFXmrkbpWrztCvoLvGKD5sh7c"
              strokeWidth={3}
              origin={{
                latitude: location.latitude,
                longitude: location.longitude,
              }}
              destination={{
                latitude: destination.latitude,
                longitude: destination.longitude,
              }}
              strokeColor="red"
              mode="DRIVING"
            />
          ) : null}
        </MapView>
      </View>

      <Callout
        style={{
          width: 300,
          position: "absolute",
          top: 70,
          alignSelf: "center",
          zIndex: 1,
        }}
      >
        <View style={{ height: "100%" }}>
          <GooglePlacesAutocomplete
            placeholder="Enter Destination"
            autoFocus={false}
            minLength={2}
            nearbyPlacesAPI="GooglePlacesSearch"
            returnKeyType={"search"}
            fetchDetails={true}
            listViewDisplayed={"auto"}
            renderDescription={(row) => row.description}
            onPress={(data, details = null) => {
              setDestination({
                latitude: details.geometry.location.lat,
                longitude: details.geometry.location.lng,
              });
            }}
            onFail={(error) => console.log("error", error)}
            getDefaultValue={() => ""}
            query={{
              key: "AIzaSyAreXK8Y8iFXmrkbpWrztCvoLvGKD5sh7c",
              language: "en",
              components: "country:NG",
            }}
            styles={{
              textInputContainer: {
                backgroundColor: "rgba(0,0,0,0)",
                borderTopWidth: 0,
                borderBottomWidth: 1,
                borderColor: "black",
              },
              textInput: {
                marginLeft: 0,
                marginRight: 0,
                height: 48,
                color: "#5d5d5d",
                fontSize: 16,
              },
              predefinedPlacesDescription: {
                color: "#1faadb",
              },
              listView: {
                color: "black", //To see where exactly the list is
                zIndex: 1, //To popover the component outwards
                backgroundColor: "white",
              },
            }}
            currentLocation={false}
          />
        </View>
      </Callout>
    </>
  );
};

export default Map;

const styles = StyleSheet.create({
  map: {
    width: Dimensions.get("window").width,
    height: "100%",
  },
});
