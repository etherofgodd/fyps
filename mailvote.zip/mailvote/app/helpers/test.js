const data = ['12345', '123456'];

let newArray = data;

const count = [...newArray, '2435'];
console.log(data.includes('123456'));
console.log(count);

<input
  onChange={e => {
    // add to list
    if (e.target.checked) {
      setPeopleInfo([
        ...peopleInfo,
        {
          id: item.id,
          first: item.name,
          last: item.lastName,
          age: item.age,
        },
      ]);
    } else {
      // remove from list
      setPeopleInfo(peopleInfo.filter(people => people.id !== item.id));
    }
  }}
  value={peopleInfo}
  style={{margin: '20px'}}
  type="checkbox"
/>;
