import React, {useState, useContext} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  AppForm,
  AppFormField,
  ErrorMessage,
  SubmitButton,
} from '../components/forms';
import {useDispatch, useSelector} from 'react-redux';
import {login} from '../redux/actions/userActions';
import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
  email: Yup.string().required().email().label('Email'),
  password: Yup.string().required().min(6).label('Password'),
});

const LoginScreen = ({navigation}) => {
  const dispatch = useDispatch();

  const {loading, error} = useSelector(state => state.loginUser);

  const handleSubmit = async ({email, password}) => {
    dispatch(login(email, password));
  };

  const [secure, setSecure] = useState(true);

  const toggleEye = () => {
    setSecure(!secure);
  };
  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={{
          flex: 1,
          backgroundColor: 'white',
        }}>
        <View style={styles.container}>
          <View>
            <Icon name="vote" color="tomato" size={200} />
          </View>
          <View>
            <AppForm
              initialValues={{
                email: '',
                password: '',
              }}
              onSubmit={handleSubmit}
              validationSchema={validationSchema}>
              <ErrorMessage error={error} visible={true} />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                name="email"
                color="black"
                placeholder="Email"
                textContentType="emailAddress"
                iconLeft="mail"
                style={{flex: 1, fontWeight: 'bold'}}
              />
              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                iconLeft="lock"
                iconRight={secure ? 'eye' : 'eye-off'}
                name="password"
                placeholder="password"
                iconRightPress={toggleEye}
                secureTextEntry={secure}
                color="black"
                textContentType="password"
                style={{flex: 1, fontWeight: 'bold'}}
              />
              <SubmitButton title="Login" loading={loading} />
            </AppForm>
          </View>
          <View style={styles.info}>
            <View>
              <Text style={styles.infoTxt}>
                Don't have a saucevote account ?
              </Text>
            </View>
            <View>
              <TouchableOpacity
                style={styles.infobtn}
                onPress={() => navigation.navigate('RegisterScreen')}>
                <Text style={styles.infoAct}>Sign Up</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  info: {
    marginTop: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoTxt: {
    fontSize: 17,
    fontWeight: '700',
  },
  infoAct: {
    fontSize: 17,
    fontWeight: '700',
    color: 'tomato',
  },
  infobtn: {
    width: 200,
    height: 40,
    borderWidth: 2,
    borderColor: 'tomato',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: 10,
  },
});
