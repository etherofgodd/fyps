import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

import ProfileScreen from "../screens/ProfileScreen";
import Me from "../screens/Me";

const { Navigator, Screen } = createStackNavigator();
const MeNavigator = () => {
  return (
    <Navigator initialRouteName="Profile" mode="card">
      <Screen
        name="Profile"
        component={ProfileScreen}
        options={{ headerShown: false }}
      />
      <Screen
        name="Me"
        component={Me}
        options={{
          headerShown: true,
          headerStyle: { backgroundColor: "#070606" },
          headerTintColor: "white",
        }}
      />
    </Navigator>
  );
};

export default MeNavigator;
