import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';
import {castVote} from '../redux/actions/voteActions';

const VoteScreen = ({route}) => {
  const {candidate_Id, electionId} = route.params;

  const dispatch = useDispatch();
  const {data, error, loading, success} = useSelector(state => state.userVote);

  const vote = () => {
    dispatch(castVote(electionId, candidate_Id));
  };
  return (
    <View style={styles.ctn}>
      {error && (
        <View>
          <Text style={{color: 'red', fontWeight: 'bold', marginBottom: 20}}>
            {error}
          </Text>
        </View>
      )}
      {success && (
        <View>
          <Text style={{color: 'green', fontWeight: 'bold', marginBottom: 20}}>
            Vote was successfully casted
          </Text>
        </View>
      )}
      {loading ? (
        <ActivityIndicator size="large" color="tomato" />
      ) : (
        <TouchableOpacity style={styles.voteCircle} onPress={() => vote()}>
          <Text style={styles.voteTxt}>VOTE</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

export default VoteScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  voteCircle: {
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: 'tomato',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 3,
  },
  voteTxt: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 30,
  },
});
