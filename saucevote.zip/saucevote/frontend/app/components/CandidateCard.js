import React from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const CandidateCard = ({party, description, name, onPress, votes}) => {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <View
        style={{
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <View style={{flexDirection: 'column', flexShrink: 1}}>
          <Text style={{fontSize: 17, color: 'grey', fontWeight: 'bold'}}>
            Party : {party}
          </Text>
          <View>
            <Icon name="account" size={100} color="tomato" />
          </View>
          <Text style={{fontWeight: 'bold', fontSize: 17}}>{name}</Text>

          <Text
            numberOfLines={2}
            style={{
              flexWrap: 'wrap',
              textAlign: 'justify',
              fontStyle: 'italic',
            }}>
            {description}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default CandidateCard;

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    width: '45%',
    height: 270,
    borderRadius: 10,
    elevation: 3,
    justifyContent: 'space-between',
    padding: 10,
    margin: 10,
    borderWidth: 2,
    borderColor: 'tomato',
  },
});
