import expressAsyncHandler from "express-async-handler";
import Addiction from "../models/addictionModel.js";

export const addAddiction = expressAsyncHandler(async (req, res) => {
  let { drug, stage } = req.body;

  if (!drug || !stage) {
    return res.status(400).json({
      message: "Invalid parameters",
    });
  }

  const addictionExist = await Addiction.where({
    drug: drug,
    stage: stage,
    user: req.user._id,
  });

  console.log(addictionExist);
  if (addictionExist.length >= 1) {
    return res.status(400).json({
      message: "User has already been diagnosed",
    });
  }

  const addiction = await Addiction.create({
    drug,
    stage,
    user: req.user._id,
  });

  if (addiction) {
    return res.status(201).json({
      message: "New addiction Added Successfully",
    });
  } else {
    return res.status(500).json({
      message: "Can't save addiction",
    });
  }
});
