import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import CandidateScreen from '../screens/CandidateScreen';
import VoteScreen from '../screens/VoteScreen';

const {Navigator, Screen} = createStackNavigator();
export default function VoteNavigator() {
  return (
    <Navigator>
      <Screen
        name="Home"
        component={HomeScreen}
        options={{headerShown: false}}
      />
      <Screen
        name="Candidates"
        component={CandidateScreen}
        options={{headerShown: false}}
      />

      <Screen
        name="Vote"
        component={VoteScreen}
        options={{headerShown: false}}
      />
    </Navigator>
  );
}
