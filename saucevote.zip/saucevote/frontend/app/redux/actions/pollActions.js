import {polls} from '../../api/polls';
import {
  GET_ALL_POLLS_FAIL,
  GET_ALL_POLLS_REQUEST,
  GET_ALL_POLLS_SUCCESS,
} from '../constants/pollConstants';

export const getAllPolls = () => async dispatch => {
  try {
    dispatch({
      type: GET_ALL_POLLS_REQUEST,
    });

    const response = await polls();

    if (response.ok) {
      dispatch({
        type: GET_ALL_POLLS_SUCCESS,
        payload: response.data.elections,
      });
    } else {
      dispatch({
        type: GET_ALL_POLLS_FAIL,
        payload:
          response.problem === 'NETWORK_ERROR'
            ? 'NETWORK ERROR'
            : response.data.message,
      });
    }
    // ok
    //   ? dispatch({
    //       type: GET_ALL_POLLS_SUCCESS,
    //       payload: data.elections,
    //     })
    //   : dispatch({
    //       type: GET_ALL_POLLS_FAIL,
    //       payload: data.message ? data.message : 'Failed',
    //     });
  } catch (error) {
    console.log(error);
    dispatch({
      type: GET_ALL_POLLS_FAIL,
      payload: error,
    });
  }
};
