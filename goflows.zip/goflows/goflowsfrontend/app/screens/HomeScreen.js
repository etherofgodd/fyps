import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Button,
  FlatList,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { FontAwesome } from "@expo/vector-icons";
import report from "../api/report";

const locs = [
  {
    loc: "NONE",
    id: "",
  },
  {
    loc: "Ikeja",
    id: "ikeja",
  },
  {
    loc: "Mowe",
    id: "mowe",
  },
  {
    loc: "Ajah",
    id: "ajah",
  },
  {
    loc: "Ikota",
    id: "ikota",
  },
  {
    loc: "Ikoyi",
    id: "ikoyi",
  },
  {
    loc: "Ikate",
    id: "ikate",
  },
  {
    loc: "Badore",
    id: "badore",
  },
  {
    loc: "Epe",
    id: "epe",
  },
  {
    loc: "Akoka",
    id: "akoka",
  },
  {
    loc: "Oshodi",
    id: "oshodi",
  },
];

const HomeScreen = ({ navigation }) => {
  const [searchLocs, setSearchLocs] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState();
  const [searchKeywords, setSearchKeywords] = useState("");
  const [reports, setReports] = useState();

  useEffect(() => {
    getReports();
  }, [searchLocs]);

  const getReports = async () => {
    try {
      setLoading(true);
      setErrorMessage();
      const res = await report.get(searchLocs, "");
      setLoading(false);

      if (res.data) {
        if (res.data.message) {
          setErrorMessage(res.data.message);
        }
        setReports(res.data.reports);
      } else {
        if (res.problem === "NETWORK_ERROR") {
          setErrorMessage("NETWORK ERROR");
        }
        if (res.problem === "SERVER_ERROR") {
          setErrorMessage("SERVER ERROR");
        }
      }
    } catch (error) {
      setLoading(false);
    }
  };

  const formatDate = (date) => {
    const funcDate = new Date(date);
    return `${funcDate.toDateString()} ${funcDate.toTimeString()}`;
  };
  return (
    <View style={styles.ctn}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <View style={styles.headerCirle}>
          <FontAwesome name="map-pin" size={30} color="black" />
        </View>
        <View
          style={{
            width: "85%",
            backgroundColor: "white",
            borderRadius: 10,
            height: 50,
            padding: 10,
          }}
        >
          <TextInput
            style={{ width: "100%", fontWeight: "bold", fontSize: 17 }}
            placeholder="Search Location"
            placeholderTextColor="black"
          />
        </View>
      </View>
      <FlatList
        keyExtractor={(item) => item.id}
        horizontal
        data={locs}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={{
              backgroundColor: "#354654",
              margin: 10,
              padding: 10,
              alignItems: "center",
              justifyContent: "center",
              borderRadius: 10,
              height: 40,
            }}
            onPress={() => setSearchLocs(item.id)}
          >
            <Text style={{ color: "white", fontWeight: "bold" }}>
              {item.loc}
            </Text>
          </TouchableOpacity>
        )}
      />

      {loading ? (
        <View style={{ flex: 1 }}>
          <ActivityIndicator size="large" color="white" />
        </View>
      ) : errorMessage ? (
        <View style={{ flex: 1, alignItems: "center" }}>
          <Text style={{ color: "red", fontWeight: "bold", fontSize: 20 }}>
            {errorMessage}
          </Text>
          <Button title="RETRY" onPress={() => getReports()} color="#354654" />
        </View>
      ) : (
        <FlatList
          data={reports}
          keyExtractor={(item) => item._id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={{ marginVertical: 10 }}
              onPress={() => navigation.navigate("Report", item)}
            >
              <View style={styles.bump}>
                <Text
                  style={{
                    color: "white",
                    fontSize: 20,
                    textTransform: "uppercase",
                    fontWeight: "bold",
                  }}
                >
                  {item.location}
                </Text>
              </View>
              <View style={styles.card}>
                <View>
                  <Text
                    style={{ color: "white", fontSize: 20, fontWeight: "bold" }}
                  >
                    From: {item.startFrom}
                  </Text>
                </View>
                <View>
                  <Text
                    style={{ color: "white", fontSize: 20, fontWeight: "bold" }}
                  >
                    To: {item.startTo}
                  </Text>
                </View>

                <View>
                  <Text
                    style={{ color: "white", fontSize: 20, fontWeight: "bold" }}
                  >
                    Time: {formatDate(item.createdAt)}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: "#070606",
    paddingTop: 15,
    padding: 10,
  },
  card: {
    backgroundColor: "#354654",
    borderTopRightRadius: 10,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    justifyContent: "space-between",
    padding: 10,
    height: 150,
  },
  bump: {
    padding: 10,
    width: 100,
    backgroundColor: "#354654",
    borderTopEndRadius: 10,
    borderTopLeftRadius: 10,
    borderBottomWidth: 3,
  },
  headerCirle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "white",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
  },
  header: {
    alignItems: "center",
    flexDirection: "row",
    marginBottom: 20,
    padding: 10,
    borderBottomWidth: 1,
    borderColor: "white",
  },
});
