import vote from '../../api/vote';
import authStorage from '../../auth/storage';
import {
  VOTE_FAIL,
  VOTE_REQUEST,
  VOTE_SUCCESS,
} from '../constants/voteConstants';

export const castVote = (election_Id, candidate_Id) => async dispatch => {
  try {
    dispatch({
      type: VOTE_REQUEST,
    });

    const user = await authStorage.getUser();
    console.log(user);

    const {ok, originalError, data} = await vote(
      election_Id,
      user.id,
      candidate_Id,
      user.voterId,
    );

    console.log(originalError);

    !ok
      ? dispatch({
          type: VOTE_FAIL,
          payload: data.message ? data.message : originalError.message,
        })
      : dispatch({
          type: VOTE_SUCCESS,
          payload: data,
        });
  } catch (error) {
    dispatch({
      type: VOTE_FAIL,
      payload: error.message ? error.message : 'Server Error',
    });
  }
};
