import React, {useState} from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
  ScrollView,
} from 'react-native';
import * as Yup from 'yup';
import {useDispatch, useSelector} from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import {
  AppForm,
  AppFormField,
  ErrorMessage,
  SubmitButton,
} from '../components/forms';
import AppDatePicker from '../components/forms/AppDatePicker';
import {register} from '../redux/actions/userActions';

const phoneRegExp =
  /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

const validationSchema = Yup.object().shape({
  email: Yup.string().required().email().label('Email'),
  password: Yup.string().required().min(6).label('Password'),
  name: Yup.string().required().label('Name'),
  phonenumber: Yup.string()
    .matches(phoneRegExp, 'Phone Number is not valid')
    .label('Phone Number')
    .length(11),
  date: Yup.date().required().label('Date'),
});

const RegisterScreen = ({navigation}) => {
  const [date, setDate] = useState(new Date());
  const [secure, setSecure] = useState(true);

  const toggleEye = () => {
    setSecure(!secure);
  };

  const dispatch = useDispatch();

  const {loading, error, success} = useSelector(state => state.registerUser);
  console.log(loading, success);

  const handleSubmit = async ({email, password, name, phonenumber, date}) => {
    try {
      dispatch(register(name, email, phonenumber, password, date));
    } catch (error) {
      console.log('from here::: ', error);
    }
  };

  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.container}>
          <View style={{paddingTop: 20}}>
            <Icon name="vote" color="tomato" size={200} />
          </View>
          <KeyboardAvoidingView>
            <AppForm
              initialValues={{
                email: '',
                password: '',
                name: '',
                phonenumber: '',
                date: date,
              }}
              onSubmit={handleSubmit}
              validationSchema={validationSchema}>
              <ErrorMessage error={error} visible={error} />

              <AppFormField
                autoCapitalize="words"
                autoCorrect={false}
                name="name"
                color="black"
                iconLeft="account-circle"
                placeholder="Full Name"
                style={{flex: 1, fontWeight: 'bold', color: 'black'}}
              />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                name="email"
                color="black"
                placeholder="Email"
                textContentType="emailAddress"
                iconLeft="mail"
                style={{flex: 1, fontWeight: 'bold'}}
              />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                iconLeft="phone"
                color="black"
                name="phonenumber"
                placeholder="Phone Number"
                keyboardType="number-pad"
                style={{flex: 1, fontWeight: 'bold'}}
              />

              <AppDatePicker name="date" />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                iconLeft="lock"
                iconRight={secure ? 'eye' : 'eye-off'}
                name="password"
                placeholder="password"
                iconRightPress={toggleEye}
                secureTextEntry={secure}
                textContentType="password"
                color="black"
                style={{flex: 1, fontWeight: 'bold'}}
              />
              <SubmitButton title="Register" loading={loading} />
            </AppForm>
          </KeyboardAvoidingView>
          <View style={styles.info}>
            <View>
              <Text style={styles.infoTxt}>Already have an account ? </Text>
            </View>
            <View>
              <TouchableOpacity
                style={styles.infobtn}
                onPress={() => navigation.navigate('LoginScreen')}>
                <Text style={styles.infoAct}>Login</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  info: {
    marginTop: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoTxt: {
    fontSize: 17,
    fontWeight: '700',
  },
  infoAct: {
    fontSize: 17,
    fontWeight: '700',
    color: 'tomato',
  },
  infobtn: {
    width: 200,
    height: 40,
    borderWidth: 2,
    borderColor: 'tomato',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: 10,
  },
});
