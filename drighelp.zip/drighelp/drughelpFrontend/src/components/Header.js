import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Header = () => {
  const [user, setUser] = useState();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token !== typeof "undefined") {
      setUser(token);
    }
  }, []);

  const logOut = () => {
    localStorage.removeItem("token");
    window.location.replace("/");
  };

  return (
    <>
      <div className="logo">
        <h1 style={{ fontWeight: "bolder" }}>
          <Link to="/">ColdTurkey</Link>
        </h1>
      </div>

      <div className="btns">
        <ul>
          <li>
            <div>
              {user ? (
                <>
                  <Link to="/dashbaord" className="nav_btn">
                    Dashboard
                  </Link>{" "}
                  <Link to="/help" className="nav_btn">
                    Diagnosis
                  </Link>
                  <button
                    onClick={() => logOut()}
                    className="headerbtn"
                    style={{
                      background: "red",
                      border: "none",
                      fontWeight: "bolder",
                      color: "white",
                      cursor: "pointer",
                    }}
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <a href="/signin" className="headerbtn">
                  Sign In
                </a>
              )}

              {/* <button className="headerbtn" onClick={() => {}}>
                Sign In
              </button> */}
            </div>
          </li>
        </ul>
      </div>
    </>
  );
};

export default Header;
