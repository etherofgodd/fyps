import React from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Entypo } from "@expo/vector-icons";

const ReportDetailScreen = ({ navigation, route }) => {
  const item = route.params;

  const formatDate = (date) => {
    const funcDate = new Date(date);
    return `${funcDate.toDateString()} ${funcDate.toTimeString()}`;
  };

  return (
    <View style={styles.ctn}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginVertical: 10,
        }}
      >
        <TouchableOpacity
          style={{
            width: 50,
            height: 50,
            borderRadius: 25,
            backgroundColor: "#fff",
            justifyContent: "center",
            alignItems: "center",
            alignSelf: "flex-start",
            marginTop: 10,
          }}
          onPress={() => navigation.goBack()}
        >
          <Entypo name="arrow-left" size={30} color="black" />
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            width: 50,
            height: 50,
            borderRadius: 25,
            backgroundColor: "#fff",
            justifyContent: "center",
            alignItems: "center",
            alignSelf: "flex-end",
            marginTop: 10,
          }}
          onPress={() => navigation.navigate("Map")}
        >
          <Entypo name="map" size={30} color="black" />
        </TouchableOpacity>
      </View>
      <ScrollView
        style={{ width: "100%" }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.reportCard}>
          <Text style={styles.reportHeader}>Traffic Route</Text>

          <View>
            <Text style={styles.reportText}>From: {item.startFrom}</Text>
          </View>
          <View>
            <Text style={styles.reportText}>To: {item.startTo}</Text>
          </View>
        </View>
        <View style={styles.reportCard}>
          <Text style={styles.reportHeader}>Alternate Route</Text>
          <View>
            <Text style={styles.reportText}>From: {item.altFrom}</Text>
          </View>
          <View>
            <Text style={styles.reportText}>To: {item.altTo}</Text>
          </View>
        </View>
        <View
          style={{
            padding: 10,
            backgroundColor: "#354654",
            marginTop: 10,
            borderRadius: 5,
          }}
        >
          <Text style={styles.reportText}>
            Time: {formatDate(item.createdAt)}
          </Text>
        </View>
        <View style={styles.reportCard}>
          <Text style={{ color: "white", fontSize: 20, fontWeight: "bold" }}>
            Description
          </Text>
          <Text style={styles.reportText}>{item.desc}</Text>
        </View>
      </ScrollView>
    </View>
  );
};

export default ReportDetailScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: "black",
    padding: 20,
    paddingTop: 10,
  },
  reportCard: {
    padding: 10,
    backgroundColor: "#354654",
    marginTop: 10,
    borderRadius: 10,
  },
  reportText: {
    textTransform: "capitalize",
    color: "white",
    fontWeight: "bold",
    fontSize: 17,
  },
  reportHeader: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
});
