import {
  GET_ALL_POLLS_FAIL,
  GET_ALL_POLLS_REQUEST,
  GET_ALL_POLLS_SUCCESS,
} from '../constants/pollConstants';
export const getPollsReducer = (
  state = {
    polls: [
      {
        _id: 'xxx',
        count: 0,
        isElectionValid: false,
        title: 'NONE',
        creator: 'NO ONE',
        candidates: [
          {
            candidateName: '',
            candidateParty: '',
            candidateDesc: '',
          },
        ],
        category: 'NONE',
      },
    ],
  },
  action,
) => {
  switch (action.type) {
    case GET_ALL_POLLS_REQUEST:
      return {
        loading: true,
        polls: {},
      };

    case GET_ALL_POLLS_SUCCESS:
      return {
        loading: false,
        polls: action.payload,
      };

    case GET_ALL_POLLS_FAIL:
      return {
        loading: false,
        error: action.payload,
      };

    default:
      return state;
  }
};
