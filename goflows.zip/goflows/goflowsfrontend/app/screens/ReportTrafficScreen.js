import React, { useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, View } from "react-native";
import * as Yup from "yup";
import { StatusBar } from "expo-status-bar";

import AppForm from "../components/forms/AppForm";
import AppFormField from "../components/forms/AppFormField";
import AppListPicker from "../components/forms/AppListPicker";
import SubmitButton from "../components/auth/SubmitBtn";
import useApi from "../hooks/useApi";
import Report from "../api/report";
import ErrorMessage from "../components/forms/ErrorMesage";

const validationSchema = Yup.object().shape({
  location: Yup.string().required().label("Location"),
  desc: Yup.string().label("Description"),
  startFrom: Yup.string().required().label("Start From"),
  startTo: Yup.string().required().label("Start To"),
  altFrom: Yup.string().label("Alternate Route From"),
  altTo: Yup.string().label("Alternate Route To"),
});

const ReportTrafficScreen = () => {
  const createReportApi = useApi(Report.create);
  const [error, setError] = useState();

  const handleSubmit = async (reportDetails, { resetForm }) => {
    console.log({
      reportDetails,
    });
    setError();

    const result = await createReportApi.request({
      ...reportDetails,
    });

    if (!result.ok) {
      if (result.data) setError(result.data.message);
      else {
        setError(
          "An unexpected Error occurred. Kindly check your internet connection"
        );
        console.log(`result`, result);
      }
      return;
    }

    Alert.alert("Report", "Traffic Report posted successfully");

    resetForm();
  };
  return (
    <View style={styles.ctn}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.headerTxt}>TRAFFIC ?</Text>
      </View>

      <AppForm
        initialValues={{
          location: "",
          desc: "",
          startFrom: "",
          startTo: "",
          altFrom: "",
          altTo: "",
        }}
        onSubmit={handleSubmit}
        validationSchema={validationSchema}
      >
        <ErrorMessage error={error} visible={error} />
        <AppListPicker name="location" />
        <ScrollView
          style={{ width: "100%" }}
          showsVerticalScrollIndicator={false}
        >
          <AppFormField maxlength={255} inputLabel="From" name="startFrom" />

          <AppFormField maxlength={255} inputLabel="To" name="startTo" />

          <View>
            <View>
              <Text
                style={{ color: "white", fontWeight: "bold", fontSize: 20 }}
              >
                Description ?
              </Text>
            </View>

            <AppFormField
              name="desc"
              multiline={true}
              numberOfLines={8}
              placeholder="Make it brief, and hate speech is not allowed"
              placeholderTextColor="rgba(255,255,255,0.6)"
              style={{ width: "100%", color: "white", fontWeight: "bold" }}
            />
          </View>
          <View>
            <View>
              <Text
                style={{ color: "white", fontWeight: "bold", fontSize: 20 }}
              >
                Alternative routes ?
              </Text>
            </View>

            <AppFormField inputLabel="From" name="altFrom" />
            <AppFormField inputLabel="To" name="altTo" />
          </View>
          <View style={{ alignSelf: "center" }}>
            <SubmitButton btnName="POST" loading={createReportApi.loading} />
          </View>
        </ScrollView>
      </AppForm>
    </View>
  );
};

export default ReportTrafficScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: "black",
    padding: 15,
  },
  header: {
    width: 200,
    borderWidth: 2,
    borderColor: "gray",
    marginVertical: 20,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  headerTxt: {
    color: "white",
    fontWeight: "bold",
    fontSize: 30,
  },
});
