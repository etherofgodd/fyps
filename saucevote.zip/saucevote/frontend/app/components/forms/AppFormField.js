import React from 'react';

import {useFormikContext} from 'formik';

import AppTextInput from '../AppTextInput';
import ErrorMessage from './ErrorMessage';

const AppFormField = ({
  name,
  width,
  iconLeft,
  iconRight,
  iconRightPress,
  ...otherProps
}) => {
  const {errors, setFieldTouched, setFieldValue, values, touched} =
    useFormikContext();
  return (
    <>
      <AppTextInput
        iconLeft={iconLeft}
        iconRight={iconRight}
        onBlur={() => setFieldTouched(name)}
        onChangeText={text => setFieldValue(name, text)}
        value={values[name]}
        width={width}
        iconRightPress={iconRightPress}
        {...otherProps}
      />
      <ErrorMessage error={errors[name]} visible={touched[name]} />
    </>
  );
};

export default AppFormField;
