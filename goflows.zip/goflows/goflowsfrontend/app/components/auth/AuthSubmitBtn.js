import React from "react";
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
} from "react-native";

const { width } = Dimensions.get("screen");

const AuthSubmitBtn = ({ loading, btnName, onPress }) => {
  return loading ? (
    <ActivityIndicator color={"#4268bc"} size={"large"} />
  ) : (
    <TouchableOpacity style={styles.btn} onPress={onPress}>
      <Text style={{ color: "white", fontWeight: "bold", fontSize: 20 }}>
        {btnName}
      </Text>
    </TouchableOpacity>
  );
};

export default AuthSubmitBtn;

const styles = StyleSheet.create({
  btn: {
    backgroundColor: "#4268bc",
    padding: 10,
    marginVertical: 20,
    width: width - 100,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 10,
    height: 70,
  },
});
