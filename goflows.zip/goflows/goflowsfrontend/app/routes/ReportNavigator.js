import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import HomeScreen from "../screens/HomeScreen";
import ReportDetailScreen from "../screens/ReportDetailScreen";
import MapScreen from "../screens/MapScreen";

const { Navigator, Screen } = createStackNavigator();
const ReportNavigator = () => {
  return (
    <Navigator initialRouteName="Home" mode="modal">
      <Screen
        name="Home"
        component={HomeScreen}
        options={{ headerShown: false }}
      />
      <Screen
        name="Report"
        component={ReportDetailScreen}
        options={{ headerShown: false }}
      />
      <Screen
        name="Map"
        component={MapScreen}
        options={{ headerShown: false }}
      />
    </Navigator>
  );
};

export default ReportNavigator;
