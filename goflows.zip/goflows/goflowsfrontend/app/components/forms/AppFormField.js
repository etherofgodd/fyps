import React from "react";
import { useFormikContext } from "formik";
import ErrorMessage from "./ErrorMesage";
import AppTextInput from "../AppTextInput";

const AppFormField = ({
  name,
  width,
  inputLabel,
  placeholder,
  ...otherProps
}) => {
  const { setFieldTouched, setFieldValue, errors, touched, values, resetForm } =
    useFormikContext();

  return (
    <>
      <AppTextInput
        inputLabel={inputLabel}
        onBlur={() => setFieldTouched(name)}
        onChangeText={(text) => setFieldValue(name, text)}
        value={values[name]}
        width={"100%"}
        placeholder={placeholder}
        {...otherProps}
        resetForm={resetForm}
      />
      <ErrorMessage error={errors[name]} visible={touched[name]} />
    </>
  );
};

export default AppFormField;
