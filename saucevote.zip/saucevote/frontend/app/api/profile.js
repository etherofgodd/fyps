import client from './client';

export const profile = () => client.get('/auth/profile', {});
