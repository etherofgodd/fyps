import expressAsyncHandler from "express-async-handler";
import Drug from "../models/drugModel.js";

// @desc Create Drug
// @route POST /api/election
// @access private

export const createDrug = expressAsyncHandler(async (req, res) => {
  let { title, info, effects, addiction } = req.body;

  if (!title || !info || !effects || !addiction) {
    return res.status(400).json({
      message: "Insufficient parameters, check and try again",
    });
  }

  const drugExists = await Drug.findOne({ title });

  if (drugExists) {
    return res.status(400).json({
      message: "Duplicate Drug not allowed",
    });
  }

  const drug = await Drug.create({
    title,
    info,
    effects,
    addiction,
  });

  if (drug) {
    return res.status(201).json({
      message: "New Drug Added Successfully",
    });
  } else {
    return res.status(500).json({
      message: "Can't save drug",
    });
  }
});

export const getDrugs = expressAsyncHandler(async (req, res) => {
  const drugs = await Drug.find();

  if (!drugs)
    return res.status(404).json({
      message: "No drugs found",
    });

  return res.status(200).json({
    message: "Drugss found",
    drugs,
  });
});

export const getDrugById = expressAsyncHandler(async (req, res) => {
  const drugId = req.params.drugId;
  if (!drugId)
    return res.status(400).json({
      message: "No id given",
    });

  const drug = await Drug.findById({ _id: drugId });

  if (drug)
    return res.status(200).json({
      drug,
    });

  res.status(404).json({
    message: "No Drug found",
  });
});
