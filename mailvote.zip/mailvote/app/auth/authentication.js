import {auth, db} from '../config/firebaseconnect';

export const logInUser = async (email, password) => {
  try {
    const isSignedIn = await auth.signInWithEmailAndPassword(email, password);

    if (!isSignedIn) {
      return {
        error: "Can't sign in",
      };
    }
  } catch (error) {
    console.log(error);
    if (error.code === 'auth/user-not-found') {
      return 'User does not exists';
    }

    if (error.code === 'auth/wrong-password') {
      return 'Invalid credentials';
    }

    // return 'Server error';
  }
};

export const verifyUser = async (bvn, email) => {
  try {
    const bvnDoc = await db.collection('bvn').doc(bvn).get();

    if (bvnDoc.exists) {
      return bvnDoc.data();
    }

    if (!bvnDoc.exists) {
      return {error: 'User does not exist'};
    }
  } catch (error) {
    console.log(error.code);

    if (error.code === 'firestore/unavailable') {
      return {error: 'Server Error'};
    }

    return {
      error: 'Network Error',
    };
  }
};

export const signUserUpWithMailandRegUser = async (
  email,
  password,
  account_name,
  phonenumber,
  account_number,
  state_of_origin,
  bvn,
) => {
  try {
    console.log('I reached here');
    const isRegistered = await auth.createUserWithEmailAndPassword(
      email,
      password,
    );

    try {
      const sentEmail = await isRegistered.user.sendEmailVerification({
        handleCodeInApp: false,
        url: 'https://mailvote.page.link/verify',
        android: {
          packageName: 'com.mailvote',
          installApp: false,
        },
      });
      sentEmail && 'Email Sent';
    } catch (error) {
      return 'Error Sending Mail';
    }

    const currentUser = auth.currentUser.uid;

    isRegistered.user.updateProfile({
      displayName: account_name,
    });

    try {
      await db
        .collection('Users')
        .doc(currentUser)
        .set({
          email,
          password,
          account_name,
          phonenumber,
          account_number,
          state_of_origin,
          bvn,
          userId: currentUser,
          voterId:
            Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
        });
    } catch (error) {
      return 'Error Saving User details';
    }
  } catch (error) {
    console.log(error);
    if (error.code === 'auth/email-already-in-use') {
      return 'That email address is already in use!';
    }

    if (error.code === 'auth/invalid-email') {
      return 'That email address is invalid!';
    }

    console.log(error);
    return 'Server error';
  }
};

export const getUserProfile = async () => {
  const id = auth.currentUser.uid;

  try {
    const user = await db.collection('Users').doc(id).get();

    if (user.exists) {
      return user.data();
    }
  } catch (error) {
    console.log(error);
  }
};
