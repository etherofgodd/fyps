import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
} from 'react-native';
import {getUserProfile} from '../auth/authentication';
import {castVote} from '../helpers/vote';

const VoteScreen = ({route, navigation}) => {
  const {index, item} = route.params;
  console.log(item);
  const [user, setUser] = useState([]);
  const [message, setmessage] = useState();
  const [errorMessage, setErrorMessage] = useState();
  useEffect(() => {
    getUserProfileDetails();
  }, []);

  const getUserProfileDetails = async () => {
    try {
      const res = await getUserProfile();
      setUser(res);
    } catch (error) {
      console.log(error);
    }
  };

  const handleVote = async () => {
    setmessage();
    setErrorMessage();
    try {
      const res = await castVote(user.voterId, index, item.poll_id);
      console.log(res);

      res.error && setErrorMessage(res.error);
      res.message && setmessage(res.message);

      // Alert.alert('Vote Successfull ', 'you can only vote once', [
      //   {
      //     text: 'ok',
      //     style: 'destructive',
      //   },
      // ]);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <View style={styles.ctn}>
      <View>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{fontSize: 20, fontWeight: 'bold'}}>GO BACK</Text>
        </TouchableOpacity>
      </View>
      <View
        style={{
          flex: 2,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        <Text style={{color: 'green'}}>{message && message}</Text>
        <Text style={{color: 'red'}}>{errorMessage && errorMessage}</Text>
        <TouchableOpacity style={styles.btn} onPress={handleVote}>
          <Text style={{color: 'white', fontWeight: 'bold'}}>Cast Vote</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default VoteScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: 'white',
    padding: 20,
  },

  btn: {
    width: '70%',
    padding: 10,
    marginVertical: 20,
    backgroundColor: '#0C2D48',
    elevation: 4,
    alignItems: 'center',
    borderRadius: 6,
    alignSelf: 'center',
  },
});
