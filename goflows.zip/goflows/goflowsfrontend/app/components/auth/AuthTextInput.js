import React from "react";
import { StyleSheet, View, TextInput, Dimensions } from "react-native";

const { width } = Dimensions.get("screen");
const AuthTextInput = ({ placeholder, ...otherProps }) => {
  return (
    <View style={styles.inputCtn}>
      <TextInput
        style={{ color: "white", fontWeight: "bold", fontSize: 20 }}
        placeholder={placeholder}
        placeholderTextColor="gray"
        {...otherProps}
      />
    </View>
  );
};

export default AuthTextInput;

const styles = StyleSheet.create({
  inputCtn: {
    width: width - 60,
    backgroundColor: "#354654",
    borderRadius: 10,
    paddingLeft: 30,
    height: 70,
    marginVertical: 10,
    justifyContent: "center",
  },
});
