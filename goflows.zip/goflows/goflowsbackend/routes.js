import express from "express";
import {
  createReport,
  getReportById,
  getReports,
  getSingleUserReport,
} from "./controllers/reportController.js";
import {
  authUser,
  createUser,
  getUserProfile,
  getUsers,
} from "./controllers/userController.js";

import { protect } from "./middlewares/authMiddleware.js";

export default (app) => {
  const apiRoutes = express.Router();
  const authRoutes = express.Router();
  const reportRoutes = express.Router();

  apiRoutes.use("/auth", authRoutes);
  apiRoutes.use("/reports", reportRoutes);

  app.use(express.json());

  app.use(
    express.urlencoded({
      extended: false,
    })
  );

  //   Home route
  app.get("/", (req, res) =>
    res.json({
      note: "Welcome",
      message: "Traffic report app",
    })
  );

  // Auth Routes
  authRoutes.route("/users").get(getUsers).post(createUser);
  authRoutes.route("/login").post(authUser);
  authRoutes.route("/profile").get(protect, getUserProfile);

  // Report routes
  reportRoutes.route("/").get(getReports);
  reportRoutes.route("/new").post(protect, createReport);
  reportRoutes.route("/me").get(protect, getSingleUserReport);
  reportRoutes.route("/:report_id").get(getReportById);

  return app.use("/api", apiRoutes);
};
