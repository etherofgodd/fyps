import React from 'react';
import {StyleSheet, Text, View, FlatList, Alert} from 'react-native';
import CandidateCard from '../components/CandidateCard';

const CandidateScreen = ({route, navigation}) => {
  const electionList = route.params;
  // console.log(electionList);
  const candidates = electionList.candidates;
  const electionId = electionList._id;
  // console.log(electionList);
  return (
    <View style={styles.ctn}>
      <FlatList
        keyExtractor={(item, index) => item._id}
        data={candidates}
        numColumns={2}
        style={{backgroundColor: '#fff'}}
        showsVerticalScrollIndicator={false}
        renderItem={({item}) => (
          <CandidateCard
            name={item.candidateName}
            party={item.candidateParty}
            description={item.candidateDesc}
            votes={item.votes.length}
            onPress={() => {
              Alert.alert(
                'Ready to VOTE',
                'Are you sure that you want to vote for this candidate ? , You only vote once and there is no going back',
                [
                  {
                    text: 'Cancel',
                    style: 'destructive',
                  },
                  {
                    text: 'Yes',
                    style: 'default',
                    onPress: () =>
                      navigation.push('Authenticate', {
                        electionId: electionId,
                        candidate_Id: item._id,
                      }),
                  },
                ],
              );
            }}
          />
        )}
      />
    </View>
  );
};

export default CandidateScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    padding: 10,
    backgroundColor: 'white',
  },
});
