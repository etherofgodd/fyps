import React from 'react';
import DatePicker from 'react-native-date-picker';
import {useFormikContext} from 'formik';

import ErrorMessage from './ErrorMessage';
import {StyleSheet, Text, View} from 'react-native';

const AppDatePicker = ({name}) => {
  const {errors, setFieldValue, touched, values} = useFormikContext();
  return (
    <>
      <View style={styles.ctn}>
        <Text
          style={{
            padding: 10,
            fontWeight: '700',
            fontSize: 17,
            textTransform: 'uppercase',
          }}>
          Date of birth
        </Text>
        <DatePicker
          onDateChange={item => setFieldValue(name, item)}
          date={values[name]}
          mode="date"
        />
      </View>
      <ErrorMessage error={errors[name]} visible={touched[name]} />
    </>
  );
};

const styles = StyleSheet.create({
  ctn: {
    borderWidth: 3,
    borderRadius: 10,
    borderColor: 'tomato',
    alignSelf: 'center',
  },
});

export default AppDatePicker;
