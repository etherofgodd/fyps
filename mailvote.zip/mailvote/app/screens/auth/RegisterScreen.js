import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  AppForm,
  AppFormField,
  ErrorMessage,
  SubmitButton,
} from '../../components/forms';
import firestore from '@react-native-firebase/firestore';

import * as Yup from 'yup';
import auth from '@react-native-firebase/auth';
import {signUserUpWithMailandRegUser} from '../../auth/authentication';

const phoneRegExp =
  /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

const validationSchema = Yup.object().shape({
  email: Yup.string().required().email().label('Email'),
  password: Yup.string().required().min(6).label('Password'),
  account_name: Yup.string().required().label('Account Name'),
  state_of_origin: Yup.string().required().label('State of Origin'),
  phone_number: Yup.string()
    .matches(phoneRegExp, 'Phone Number is not valid')
    .label('Phone Number')
    .length(11)
    .required(),
  account_number: Yup.string()
    .matches(phoneRegExp, 'account Number is not valid')
    .label('Account Number')
    .length(10),
  bvn: Yup.string().label('Bank Verification Number').length(10),
});

const RegisterScreen = ({navigation, route}) => {
  const [errorMessage, setErrorMessage] = useState();
  const [loading, setLoading] = useState(false);
  const user = route.params;

  const handleSubmit = async ({
    email,
    password,
    account_name,
    phone_number,
    account_number,
    state_of_origin,
    bvn,
  }) => {
    console.log('registeration btn clicked');
    setLoading(true);
    const res = await signUserUpWithMailandRegUser(
      email,
      password,
      account_name,
      phone_number,
      account_number,
      state_of_origin,
      bvn,
    );
    console.log(res);
    setLoading(false);
    setErrorMessage(res);
  };

  console.log('right here');

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#0C2D48" />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.container}>
          <View style={styles.iconCircle}>
            <Icon name="ballot" color="#0C2D48" size={200} />
          </View>
          <View style={{width: '100%'}}>
            <View>
              <Text
                style={{fontWeight: 'bold', fontSize: 20, color: '#0C2D48'}}>
                Sign Up
              </Text>
            </View>
            <AppForm
              initialValues={{
                email: user.email,
                password: '',
                account_name: user.account_name,
                phone_number: user.phone_number,
                account_number: user.account_number,
                state_of_origin: user.state_of_origin,
                bvn: user.bvn,
              }}
              onSubmit={handleSubmit}
              validationSchema={validationSchema}>
              <ErrorMessage error={errorMessage} visible={errorMessage} />

              <AppFormField
                autoCapitalize="words"
                autoCorrect={false}
                name="account_name"
                iconLeft="account-circle"
                placeholder="Account Name"
                color="black"
                style={{flex: 1, fontWeight: 'bold'}}
                value={user.account_name}
              />

              <AppFormField
                autoCapitalize="words"
                autoCorrect={false}
                name="bvn"
                iconLeft="bank-transfer"
                color="black"
                placeholder="BVN"
                style={{flex: 1, fontWeight: 'bold'}}
                value={user.bvn}
              />

              <AppFormField
                autoCapitalize="words"
                autoCorrect={false}
                name="account_number"
                iconLeft="bank"
                placeholder="Account Number"
                color="black"
                style={{flex: 1, fontWeight: 'bold'}}
                value={user.account_number}
              />

              <AppFormField
                autoCapitalize="words"
                autoCorrect={false}
                name="state_of_origin"
                iconLeft="home"
                placeholder="State of Origin"
                style={{flex: 1, fontWeight: 'bold'}}
                value={user.state_of_origin}
                color="black"
              />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                name="email"
                placeholder="Email"
                textContentType="emailAddress"
                iconLeft="mail"
                style={{flex: 1, fontWeight: 'bold'}}
                value={user.email}
                color="black"
              />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                iconLeft="phone"
                name="phonenumber"
                placeholder="Phone Number"
                keyboardType="number-pad"
                style={{flex: 1, fontWeight: 'bold'}}
                value={user.phone_number}
                color="black"
              />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                iconRight="eye"
                iconLeft="lock"
                name="password"
                placeholder="password"
                secureTextEntry
                textContentType="password"
                style={{flex: 1, fontWeight: 'bold'}}
                color="black"
              />

              <SubmitButton title="Sign Up" loading={loading} />
            </AppForm>
          </View>

          <View style={styles.info}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <View style={styles.line} />
              <Text style={{fontWeight: 'bold', fontSize: 20}}>Or</Text>
              <View style={styles.line} />
            </View>
            <View style={styles.authAct}>
              <TouchableOpacity
                onPress={() => navigation.navigate('LoginScreen')}>
                <Text style={styles.txt}>Sign In</Text>
              </TouchableOpacity>
              <TouchableOpacity>
                <Text style={styles.txt}>About</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    padding: 20,
  },
  info: {
    marginTop: 15,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },

  iconCircle: {
    borderWidth: 2,
    width: 230,
    height: 230,
    borderRadius: 115,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#0C2D48',
    elevation: 2,
    backgroundColor: 'white',
    marginBottom: 20,
  },
  line: {
    borderWidth: 1,
    width: 100,
    height: 1,
    marginHorizontal: 9,
    borderColor: '#0C2D48',
  },
  authAct: {
    height: 90,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  txt: {
    fontWeight: 'bold',
    fontSize: 20,
  },
});
