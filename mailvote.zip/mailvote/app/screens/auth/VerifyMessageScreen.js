import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const VerifyMessageScreen = () => {
  return (
    <View style={{justifyContent: 'center', alignItems: 'center', flex: 1}}>
      <Text>Please verify your email 😄</Text>
    </View>
  );
};

export default VerifyMessageScreen;

const styles = StyleSheet.create({});
