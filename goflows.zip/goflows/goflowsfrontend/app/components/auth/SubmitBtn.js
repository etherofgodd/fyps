import React from "react";
import { useFormikContext } from "formik";

import AuthSubmitBtn from "./AuthSubmitBtn";

function SubmitButton({ btnName, loading }) {
  const { handleSubmit } = useFormikContext();

  return (
    <AuthSubmitBtn btnName={btnName} onPress={handleSubmit} loading={loading} />
  );
}

export default SubmitButton;
