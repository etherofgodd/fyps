const Footer = () => {
  return <h4>Made with ❤️ by Ewulu Caleb</h4>;
};

export default Footer;
