import React, { useState } from "react";
import { useFormikContext } from "formik";
import Icon from "@expo/vector-icons/FontAwesome";
import DropDownPicker from "react-native-dropdown-picker";

import ErrorMessage from "./ErrorMesage";

const AppListPicker = ({ name }) => {
  const { errors, setFieldValue, touched, values } = useFormikContext();
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(null);
  const [items, setItems] = useState([
    {
      label: "Ikeja",
      value: "ikeja",
      selectable: true,
    },
    {
      label: "Mowe",
      value: "mowe",
      selectable: true,
    },
    {
      label: "Ajah",
      value: "ajah",
      selectable: true,
    },
    {
      label: "Ikota",
      value: "ikota",
      selectable: true,
    },
    {
      label: "Ikoyi",
      value: "ikoyi",
      selectable: true,
    },
    {
      label: "Ikate",
      value: "ikate",
      selectable: true,
    },
    {
      label: "Badore",
      value: "badore",
      selectable: true,
    },
    {
      label: "Epe",
      value: "epe",
      selectable: true,
    },
    {
      label: "Akoka",
      value: "akoka",
      selectable: true,
    },
    {
      label: "Oshodi",
      value: "oshodi",
      selectable: true,
    },
  ]);

  return (
    <>
      <DropDownPicker
        open={open}
        value={values[name]}
        items={items}
        setOpen={setOpen}
        setValue={(val) => {
          setValue(val);
          setFieldValue(name, value);
        }}
        setItems={setItems}
        placeholder="Choose Location"
      />
      <ErrorMessage error={errors[name]} visible={touched[name]} />
    </>
  );
};

export default AppListPicker;
