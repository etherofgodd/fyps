import React, {useState} from 'react';
import {StyleSheet, Text, View, StatusBar, ScrollView} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import * as Yup from 'yup';
import {verifyUser} from '../../auth/authentication';

import {
  AppForm,
  AppFormField,
  ErrorMessage,
  SubmitButton,
} from '../../components/forms';

const validationSchema = Yup.object().shape({
  bvn: Yup.string().label('Bank Verification Number').length(10),
  email: Yup.string().required().email().label('Email'),
});

const VerifyScreen = ({navigation}) => {
  const [errorMessage, setErrorMessage] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState([]);

  const handleSubmit = async ({bvn, email}) => {
    setUser([]);
    setErrorMessage('');
    setIsLoading(true);
    const res = await verifyUser(bvn, email);
    setIsLoading(false);

    if (res.error) {
      setErrorMessage(res.error);
    } else {
      setUser(res);
    }

    if (user.length !== 0) {
      navigation.navigate('RegisterScreen', user);
    }
  };

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#0C2D48" />

      <ScrollView
        style={{
          width: '100%',
          height: '100%',
          backgroundColor: 'white',
        }}
        showsVerticalScrollIndicator={false}>
        <View style={styles.container}>
          <View style={styles.iconCircle}>
            <Icon name="ballot" color="#0C2D48" size={200} />
          </View>
          <View>
            <View>
              <Text
                style={{fontWeight: 'bold', fontSize: 20, color: '#0C2D48'}}>
                Verify Credentials
              </Text>
            </View>
            <AppForm
              initialValues={{email: '', bvn: ''}}
              onSubmit={handleSubmit}
              validationSchema={validationSchema}>
              <ErrorMessage error={errorMessage} visible={errorMessage} />

              <AppFormField
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                name="email"
                placeholder="Email"
                textContentType="emailAddress"
                color="black"
                iconLeft="email"
                style={{flex: 1, fontWeight: 'bold'}}
              />
              <AppFormField
                autoCapitalize="words"
                autoCorrect={false}
                name="bvn"
                iconLeft="bank-transfer"
                color="black"
                placeholder="BVN"
                style={{flex: 1, fontWeight: 'bold'}}
              />
              <SubmitButton title="Verify" loading={isLoading} />
            </AppForm>
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default VerifyScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    padding: 20,
  },
  info: {
    marginTop: 15,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },

  iconCircle: {
    borderWidth: 2,
    width: 230,
    height: 230,
    borderRadius: 115,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#0C2D48',
    elevation: 2,
    backgroundColor: 'white',
    marginBottom: 20,
  },
  line: {
    borderWidth: 1,
    width: 100,
    height: 1,
    marginHorizontal: 9,
    borderColor: '#0C2D48',
  },
  authAct: {
    height: 90,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  txt: {
    fontWeight: 'bold',
    fontSize: 20,
  },
});
