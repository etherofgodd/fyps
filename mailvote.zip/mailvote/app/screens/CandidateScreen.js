import React from 'react';
import {FlatList, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import CandidateCard from '../components/CandidateCard';

const CandidateScreen = ({navigation, route}) => {
  const info = route.params;

  return (
    <View style={styles.ctn}>
      <FlatList
        keyExtractor={item => item.candidate_id}
        data={info.candidates}
        style={{width: '100%'}}
        ListHeaderComponent={() => (
          <View>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Text style={{fontSize: 20, fontWeight: 'bold'}}>GO BACK</Text>
            </TouchableOpacity>
          </View>
        )}
        showsVerticalScrollIndicator={false}
        renderItem={({item, index}) => (
          <CandidateCard
            name={item.candidate_name}
            desc={item.candidate_desc}
            party={item.candidate_party}
            onPress={() => navigation.navigate('Vote', {item, index})}
          />
        )}
      />
    </View>
  );
};

export default CandidateScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'white',
  },
});
