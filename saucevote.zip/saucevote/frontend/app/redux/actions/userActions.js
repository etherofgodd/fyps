import auth from '../../api/auth';
import {profile} from '../../api/profile';
import user from '../../api/register';
import authStorage from '../../auth/storage';

import {
  USER_LOGOUT,
  USER_DETAILS_FAIL,
  USER_DETAILS_REQUEST,
  USER_DETAILS_SUCCESS,
  USER_DETAILS_RESET,
  USER_REGISTER_FAIL,
  USER_REGISTER_SUCCESS,
  USER_REGISTER_REQUEST,
  USER_LOGIN_REQUEST,
  USER_LOGIN_SUCCESS,
  USER_LOGIN_FAIL,
} from '../constants/userContants';

export const login = (email, password) => async dispatch => {
  try {
    dispatch({
      type: USER_LOGIN_REQUEST,
    });

    const response = await auth.login(email, password);
    if (response.ok) {
      await authStorage.storeToken(response.data.token);
      const user = await authStorage.getUser();
      dispatch({
        type: USER_LOGIN_SUCCESS,
        payload: {
          token: response.data.token,
          user,
        },
      });
    } else {
      dispatch({
        type: USER_LOGIN_FAIL,
        payload:
          response.problem === 'NETWORK_ERROR'
            ? 'NETWORK ERROR'
            : response.data.message,
      });
    }
  } catch (error) {
    dispatch({
      type: USER_LOGIN_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : error.message,
    });
  }
};

export const register =
  (name, email, phonenumber, password, dob) => async dispatch => {
    try {
      dispatch({
        type: USER_REGISTER_REQUEST,
      });

      const response = await user.register({
        name,
        email,
        phonenumber,
        password,
        dob,
      });

      if (response.ok) {
        dispatch({
          type: USER_REGISTER_SUCCESS,
          payload: response.data.message,
        });

        dispatch(login(email, password));
      } else {
        dispatch({
          type: USER_REGISTER_FAIL,
          payload:
            response.problem === 'NETWORK_ERROR'
              ? 'NETWORK ERROR'
              : response.data.message,
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

export const logOut = () => async dispatch => {
  await authStorage.removeToken();
  dispatch({
    type: USER_LOGOUT,
  });
};

export const getUserDetails = () => async dispatch => {
  try {
    dispatch({
      type: USER_DETAILS_REQUEST,
    });

    const response = await profile();

    if (response.ok) {
      dispatch({
        type: USER_DETAILS_SUCCESS,
        payload: response.data.user,
      });
    } else {
      dispatch({
        type: USER_DETAILS_FAIL,
        payload:
          data.message === null
            ? 'Internal error, check connection'
            : data.message,
      });
    }
  } catch (error) {
    dispatch({
      type: USER_DETAILS_FAIL,
      payload:
        error.response && error.response.data.message
          ? error.response.data.message
          : 'Internal error, check connection',
    });
  }
};
