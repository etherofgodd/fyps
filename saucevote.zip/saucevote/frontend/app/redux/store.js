import {createStore, combineReducers, applyMiddleware} from 'redux';
import ReduxThunk from 'redux-thunk';
import {
  userLoginReducer,
  userRegisterReducer,
  logOutReducer,
  userDetailsReducer,
} from './reducers/userReducer';

import {getPollsReducer} from './reducers/pollReducer';

import {votingReducer} from './reducers/voteReducer';
const rootReducer = combineReducers({
  loginUser: userLoginReducer,
  registerUser: userRegisterReducer,
  userDetails: userDetailsReducer,
  logOutUser: logOutReducer,
  getPolls: getPollsReducer,
  userVote: votingReducer,
});

export default store = createStore(rootReducer, applyMiddleware(ReduxThunk));
