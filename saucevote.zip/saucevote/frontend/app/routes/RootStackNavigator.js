import React, {useEffect, useState} from 'react';
import {ActivityIndicator, View} from 'react-native';
import AppNavigator from './AppNavigator';
import AuthNavigator from './AuthNavigator';
import authStorage from '../auth/storage';
import {useSelector} from 'react-redux';

const RootStackNavigator = () => {
  const [user, setUser] = useState();
  const [isReady, setIsReady] = useState(false);
  const [isloading, setIsLoading] = useState(true);

  const {token} = useSelector(state => state.loginUser);

  useEffect(() => {
    getUser();
  }, [token]);

  const getUser = async () => {
    setIsLoading(true);
    setIsReady(false);
    try {
      const user = await authStorage.getUser();
      if (user) setUser(user);
      setIsReady(true);
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
      console.log(error);
    }
  };

  if (isloading) {
    return (
      <View style={{justifyContent: 'center', alignItems: 'center', flex: 1}}>
        <ActivityIndicator size="large" color="tomato" />
      </View>
    );
  }
  if (isReady) return user ? <AppNavigator /> : <AuthNavigator />;
};

export default RootStackNavigator;
