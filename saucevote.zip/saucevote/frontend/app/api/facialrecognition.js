import {create} from 'apisauce';

const URL = 'https://sacinta-face-recognition.p.rapidapi.com';

const facialrecognition = create({
  baseURL: URL,
});

export default facialrecognition;
