import React, {createRef, useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Alert,
  ActivityIndicator,
  NativeModules,
  Image,
  ScrollView,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import BottomSheet from 'reanimated-bottom-sheet';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Animated from 'react-native-reanimated';

import recognize from '../api/recognize';

const AuthuserScreen = ({route, navigation}) => {
  const {candidate_Id, electionId} = route.params;

  const bs = createRef();
  const fall = new Animated.Value(1);
  const [isLoading, setIsLoading] = useState(false);
  const [imageSrc, setimageSrc] = useState();
  const [message, setMessage] = useState('');

  useEffect(() => {
    (async () => {
      if (Platform.OS !== 'web') {
        const {status} =
          await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
          alert('Sorry, we need camera roll permissions to make this work!');
        }
      }
    })();
  }, []);

  const pickImage = async () => {
    let result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      base64: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setimageSrc(result.uri);

      setIsLoading(true);
      const res = await recognize.recognize(result.base64);
      setIsLoading(false);
      setMessage(res.message);

      // const data = {
      //   SubscriptionKey: 'cf6174e269904783b0efe1f3298a9d8e',
      //   SampleImages: {sampleNumber: result.base64},
      // };

      // try {
      //   setIsLoading(true);
      //   const res = await image.post('/recognize', data, {
      //     headers: {
      //       'content-type': 'application/json',
      //       'x-rapidapi-key':
      //         '1912477eb1mshb0cc45c3cda0331p1740ffjsnb718647bc85f',
      //       'x-rapidapi-host': 'sacinta-face-recognition.p.rapidapi.com',
      //     },
      //   });
      //   if (res) {
      //     console.log(res);
      //     setIsLoading(false);
      //     console.log(res.data);
      //     if (res.data.StatusMessage) {
      //       setMessage(res.data.StatusMessage);
      //     } else {
      //       setMessage('Network Error');
      //     }
      //   } else {
      //     console.log('OMO !!');
      //     setIsLoading(false);
      //   }
      // } catch (error) {
      //   setIsLoading(false);
      //   console.log(error);
      // }
    }
  };

  const renderInner = () => (
    <View
      style={{
        backgroundColor: 'tomato',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
      }}>
      <Text
        style={{
          fontWeight: 'bold',
          color: 'white',
          fontSize: 20,
        }}>
        Take picture
      </Text>
      <View style={{height: '100%', paddingTop: 20}}>
        <TouchableOpacity
          onPress={pickImage}
          style={{
            height: 50,
            width: 300,
            padding: 10,
            backgroundColor: 'white',
            justifyContent: 'center',
            alignItems: 'center',
            elevation: 10,
          }}>
          <Text style={{fontWeight: 'bold', fontSize: 20}}>Take Photo</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => bs.current.snapTo(1)}
          style={{
            height: 50,
            width: 300,
            padding: 10,
            backgroundColor: 'white',
            justifyContent: 'center',
            alignItems: 'center',
            elevation: 10,
            marginVertical: 20,
          }}>
          <Text style={{fontWeight: 'bold', fontSize: 20}}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderhead = () => (
    <View
      style={{
        backgroundColor: 'tomato',
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        padding: 10,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <View>
        <View>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'white',
              fontSize: 20,
            }}>
            Face Scanner
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.ctn}>
      {isLoading ? (
        <View style={{alignSelf: 'center'}}>
          <ActivityIndicator size="large" color="tomato" />
        </View>
      ) : (
        <>
          <BottomSheet
            ref={bs}
            snapPoints={[330, 0]}
            initialSnap={1}
            enabledGestureInteraction={true}
            callbackNode={fall}
            renderContent={renderInner}
            renderHeader={renderhead}
          />
          <Animated.View
            style={{
              marginHorizontal: 20,
              opacity: Animated.add(0.1, Animated.multiply(fall, 1.0)),
            }}>
            <View style={styles.header}>
              <Text style={{fontSize: 20, fontWeight: 'bold'}}>
                KINDLY VERIFY YOUR FACE, PLEASE VERIFICATION WOULD ONLY WORK IF
                YOU HAVE REGISTERED ON THE PROFILE SCREEN.
              </Text>
            </View>
            <TouchableOpacity
              style={styles.imgInput}
              onPress={() => bs.current.snapTo(0)}>
              <Icon name={'plus'} color="white" size={40} />
            </TouchableOpacity>
            <ScrollView>
              {message === '1 Face(s) Found' ? (
                <View style={{marginVertical: 10}}>
                  <Text
                    style={{fontSize: 20, color: 'green', alignSelf: 'center'}}>
                    VERIFICATION SUCCESSFUL! PROCEED TO VOTE.
                  </Text>

                  <TouchableOpacity
                    style={{
                      height: 50,
                      width: 300,
                      padding: 10,
                      backgroundColor: 'tomato',
                      justifyContent: 'center',
                      alignItems: 'center',
                      elevation: 10,
                      marginVertical: 20,
                      alignSelf: 'center',
                    }}
                    onPress={() =>
                      navigation.navigate('VoteScreen', {
                        candidate_Id,
                        electionId,
                      })
                    }>
                    <Text style={{color: 'white', fontSize: 20}}>
                      Proceed to vote
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <Text
                  style={{
                    fontSize: 20,
                    color: 'red',
                    alignSelf: 'center',
                    marginVertical: 20,
                  }}>
                  {message && message + ' !'}
                </Text>
              )}
              <Image
                style={{
                  height: 300,
                  width: 300,
                  borderRadius: 200,
                  alignSelf: 'center',
                }}
                resizeMode="contain"
                source={{uri: imageSrc}}
              />
            </ScrollView>
          </Animated.View>
        </>
      )}
    </View>
  );
};

export default AuthuserScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: 'white',
    // justifyContent: 'center',
    // alignItems: 'center',
  },
  header: {
    borderWidth: 2,
    padding: 10,
    borderColor: 'tomato',
  },
  imgInput: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: 'tomato',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
    alignSelf: 'center',
  },
});
