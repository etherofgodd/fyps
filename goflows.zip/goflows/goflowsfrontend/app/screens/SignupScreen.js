import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import * as Yup from "yup";

// components
import AppForm from "../components/forms/AppForm";
import ErrorMessage from "../components/forms/ErrorMesage";
import AuthFormField from "../components/auth/AuthFormField";
import SubmitButton from "../components/auth/SubmitBtn";

// configs
import useAuth from "../auth/useAuth";
import registerUser from "../api/register";
import loginUser from "../api/login";
import useApi from "../hooks/useApi";

const validationSchema = Yup.object().shape({
  email: Yup.string().required().email().label("Email"),
  password: Yup.string().required().min(5).label("Password"),
  confirmPassword: Yup.string().min(5).label("Confirm Password"),
});

const SignupScreen = ({ navigation }) => {
  const registerApi = useApi(registerUser);
  const loginApi = useApi(loginUser);
  const auth = useAuth();
  const [error, setError] = useState();

  const handleSubmit = async ({ email, password, confirmPassword }) => {
    setError();

    if (confirmPassword != password) {
      setError("Your passwords do not match");
      console.log("Dont match error", { password, confirmPassword });
      return;
    }

    const result = await registerApi.request(email, password);

    if (!result.ok) {
      if (result.data) setError(result.data.message);
      else {
        setError(
          "An unexpected Error occurred. Kindly check your internet connection"
        );
        console.log(`result`, result);
      }
      return;
    }

    const {
      data: { token },
    } = await loginApi.request(email, password);
    console.log(token);

    auth.logIn(token);
  };

  return (
    <View style={styles.ctn}>
      <StatusBar style="light" />
      <View
        style={{
          justifyContent: "center",
          alignItems: "center",
          marginVertical: 10,
        }}
      >
        <Text
          style={{
            fontWeight: "bold",
            fontSize: 20,
            color: "white",
            marginVertical: 10,
          }}
        >
          Create New Account
        </Text>
        <Text style={{ fontWeight: "700", fontSize: 14, color: "gray" }}>
          Please fill the form to continue
        </Text>
      </View>

      <AppForm
        initialValues={{
          email: "",
          password: "",
          confirmPassword: "",
        }}
        onSubmit={handleSubmit}
        validationSchema={validationSchema}
      >
        <ErrorMessage error={error} visible={error} />

        <AuthFormField
          name="email"
          placeholder="EMAIL"
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="email-address"
          name="email"
          textContentType="emailAddress"
        />

        <AuthFormField
          autoCapitalize="none"
          autoCorrect={false}
          name="password"
          placeholder="PASSWORD"
          secureTextEntry
          textContentType="password"
        />

        <AuthFormField
          autoCapitalize="none"
          autoCorrect={false}
          name="confirmPassword"
          placeholder="CONFIRM PASSWORD"
          secureTextEntry
          textContentType="password"
        />

        <SubmitButton btnName="SIGN UP" loading={registerApi.loading} />
      </AppForm>

      <View style={{ justifyContent: "center", flexDirection: "row" }}>
        <Text style={{ color: "white", fontWeight: "900" }}>
          Have an account ?{" "}
        </Text>
        <TouchableOpacity onPress={() => navigation.navigate("Login")}>
          <Text style={{ color: "skyblue", fontWeight: "900" }}>Sign In</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default SignupScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#070606",
    padding: 10,
  },
});
