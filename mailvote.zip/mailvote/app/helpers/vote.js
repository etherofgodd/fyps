import {db} from '../config/firebaseconnect';

export const castVote = async (voterId, index, pollId) => {
  try {
    const poll_doc = await db.collection('poll').doc(pollId).get();

    if (poll_doc.exists) {
      console.log(poll_doc.data().count);
      let voters = [];
      voters = poll_doc.data().count;
      if (voters.includes(voterId)) {
        return {
          error: 'Voter has already voted',
        };
      } else {
        // const votes = poll_doc.data()['candidates'][index]['votes'];
        // votes = votes + 1;
        if (voterId !== null || voterId !== undefined) {
          voters.push(voterId);
        }

        db.collection('poll').doc(pollId).update({
          count: voters,
        });

        return {
          message: 'Vote successful',
        };
      }
    }
    if (!poll_doc.exists) {
      console.log('Poll is invalid');
    }
  } catch (error) {
    if (error) {
      console.log(error);
      return {
        error: 'Error Performing transaction at this momment',
      };
    }
  }
};
