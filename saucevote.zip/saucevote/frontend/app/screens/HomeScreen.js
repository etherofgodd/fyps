import React, {useEffect} from 'react';
import {
  Button,
  StyleSheet,
  FlatList,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
  StatusBar,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {useDispatch, useSelector} from 'react-redux';
import {getAllPolls} from '../redux/actions/pollActions';

const HomeScreen = ({navigation}) => {
  const {width} = Dimensions.get('screen');
  const dispatch = useDispatch();

  const {loading, polls, error} = useSelector(state => state.getPolls);

  useEffect(() => {
    dispatch(getAllPolls());
  }, []);

  const newDateStuff = date => {
    return new Date(date).toLocaleDateString();
  };

  return (
    <View style={styles.ctn}>
      <StatusBar
        backgroundColor="rgba(235, 84, 36, 0.7)"
        barStyle="dark-content"
      />
      <View
        style={{
          top: 10,
          left: 20,
          position: 'absolute',
          flexDirection: 'row',
        }}>
        <TouchableOpacity
          style={styles.drawerBtn}
          onPress={() => navigation.openDrawer()}>
          <Icon name="menu" size={40} color="tomato" />
        </TouchableOpacity>
        <View style={styles.banner}>
          <Text style={{fontSize: 18, fontWeight: 'bold'}}>
            Available Elections
          </Text>
        </View>
      </View>

      {error && (
        <View>
          <Text style={{color: 'white', fontWeight: 'bold'}}>{error}</Text>
        </View>
      )}

      {!polls && (
        <View>
          <Text style={{color: 'white', fontWeight: 'bold'}}>
            No polls found
          </Text>
        </View>
      )}

      {polls && polls.length >= 1 && (
        <FlatList
          data={polls}
          keyExtractor={item => item._id}
          style={{
            marginTop: 70,
          }}
          numColumns={2}
          showsHorizontalScrollIndicator={true}
          renderItem={({item}) => (
            <TouchableOpacity
              style={styles.card}
              disabled={item.isElectionValid === false}
              onPress={() => navigation.navigate('Candidates', item)}>
              <View style={{borderBottomWidth: 2, borderColor: 'tomato'}}>
                <Text style={{fontWeight: 'bold', fontSize: 17}}>
                  <Text style={{fontSize: 20}}>{item.title}</Text>
                </Text>
              </View>
              <Text style={{marginTop: 10, fontWeight: 'bold', fontSize: 16}}>
                {item.candidates.length} Candidates
              </Text>
              <Text style={{marginTop: 10, fontWeight: 'bold', fontSize: 16}}>
                {item.count} Vote(s)
              </Text>
              <Text style={{marginTop: 10, fontWeight: 'bold', fontSize: 16}}>
                Date Created : {newDateStuff(item.createdAt)}
              </Text>
              <Text style={{marginTop: 10, fontWeight: 'bold', fontSize: 16}}>
                Election Valid: {item.isElectionValid ? 'TRUE' : 'FALSE'}
              </Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  ctn: {
    flex: 1,
    backgroundColor: 'rgba(235, 84, 36, 0.7)',
  },
  drawerBtn: {
    height: 60,
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
    elevation: 4,
    backgroundColor: '#fff',
  },

  card: {
    height: 260,
    borderRadius: 10,
    // borderWidth: 2,
    // borderColor: 'tomato',
    backgroundColor: '#fff',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    elevation: 4,
    margin: 10,
    width: '45%',
    padding: 10,
  },

  banner: {
    width: '70%',
    height: 60,
    borderRadius: 10,
    elevation: 5,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 10,
    borderColor: 'tomato',
  },
});
